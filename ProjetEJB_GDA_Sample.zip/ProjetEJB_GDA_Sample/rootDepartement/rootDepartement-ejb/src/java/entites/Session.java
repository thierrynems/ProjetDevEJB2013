/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Thierrynems
 */
@Entity
@Table(name = "session")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Session.findAll", query = "SELECT s FROM Session s"),
    @NamedQuery(name = "Session.findByIdSession", query = "SELECT s FROM Session s WHERE s.idSession = :idSession"),
    @NamedQuery(name = "Session.findByIdannee", query = "SELECT s FROM Session s WHERE s.idannee = :idannee"),
    @NamedQuery(name = "Session.findByCodesession", query = "SELECT s FROM Session s WHERE s.codesession = :codesession"),
    @NamedQuery(name = "Session.findByLibelleFr", query = "SELECT s FROM Session s WHERE s.libelleFr = :libelleFr"),
    @NamedQuery(name = "Session.findByLibelleEn", query = "SELECT s FROM Session s WHERE s.libelleEn = :libelleEn"),
    @NamedQuery(name = "Session.findByNumsession", query = "SELECT s FROM Session s WHERE s.numsession = :numsession"),
    @NamedQuery(name = "Session.findByEncours", query = "SELECT s FROM Session s WHERE s.encours = :encours"),
    @NamedQuery(name = "Session.findByPayant", query = "SELECT s FROM Session s WHERE s.payant = :payant"),
    @NamedQuery(name = "Session.findByTypesession", query = "SELECT s FROM Session s WHERE s.typesession = :typesession")})
public class Session implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idSession")
    private Integer idSession;
    @Basic(optional = false)
    @Column(name = "idannee")
    private int idannee;
    @Basic(optional = false)
    @Column(name = "codesession")
    private String codesession;
    @Basic(optional = false)
    @Column(name = "libelle_fr")
    private String libelleFr;
    @Column(name = "libelle_en")
    private String libelleEn;
    @Column(name = "numsession")
    private Integer numsession;
    @Column(name = "encours")
    private Boolean encours;
    @Column(name = "payant")
    private Short payant;
    @Column(name = "typesession")
    private String typesession;

    public Session() {
    }

    public Session(Integer idSession) {
        this.idSession = idSession;
    }

    public Session(Integer idSession, int idannee, String codesession, String libelleFr) {
        this.idSession = idSession;
        this.idannee = idannee;
        this.codesession = codesession;
        this.libelleFr = libelleFr;
    }

    public Integer getIdSession() {
        return idSession;
    }

    public void setIdSession(Integer idSession) {
        this.idSession = idSession;
    }

    public int getIdannee() {
        return idannee;
    }

    public void setIdannee(int idannee) {
        this.idannee = idannee;
    }

    public String getCodesession() {
        return codesession;
    }

    public void setCodesession(String codesession) {
        this.codesession = codesession;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleEn() {
        return libelleEn;
    }

    public void setLibelleEn(String libelleEn) {
        this.libelleEn = libelleEn;
    }

    public Integer getNumsession() {
        return numsession;
    }

    public void setNumsession(Integer numsession) {
        this.numsession = numsession;
    }

    public Boolean getEncours() {
        return encours;
    }

    public void setEncours(Boolean encours) {
        this.encours = encours;
    }

    public Short getPayant() {
        return payant;
    }

    public void setPayant(Short payant) {
        this.payant = payant;
    }

    public String getTypesession() {
        return typesession;
    }

    public void setTypesession(String typesession) {
        this.typesession = typesession;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idSession != null ? idSession.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Session)) {
            return false;
        }
        Session other = (Session) object;
        if ((this.idSession == null && other.idSession != null) || (this.idSession != null && !this.idSession.equals(other.idSession))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Session[ idSession=" + idSession + " ]";
    }
    
}
