/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Thierrynems
 */
@Entity
@Table(name = "semestre")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Semestre.findAll", query = "SELECT s FROM Semestre s"),
    @NamedQuery(name = "Semestre.findByIdSemestre", query = "SELECT s FROM Semestre s WHERE s.idSemestre = :idSemestre"),
    @NamedQuery(name = "Semestre.findByCode", query = "SELECT s FROM Semestre s WHERE s.code = :code"),
    @NamedQuery(name = "Semestre.findByLibelleFr", query = "SELECT s FROM Semestre s WHERE s.libelleFr = :libelleFr"),
    @NamedQuery(name = "Semestre.findByNumero", query = "SELECT s FROM Semestre s WHERE s.numero = :numero"),
    @NamedQuery(name = "Semestre.findByDiplomant", query = "SELECT s FROM Semestre s WHERE s.diplomant = :diplomant"),
    @NamedQuery(name = "Semestre.findByClasse", query = "SELECT s FROM Semestre s WHERE s.classe = :classe")})
public class Semestre implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idSemestre")
    private Integer idSemestre;
    @Basic(optional = false)
    @Column(name = "code")
    private String code;
    @Basic(optional = false)
    @Column(name = "libelle_fr")
    private String libelleFr;
    @Basic(optional = false)
    @Column(name = "numero")
    private int numero;
    @Basic(optional = false)
    @Column(name = "diplomant")
    private boolean diplomant;
    @Basic(optional = false)
    @Column(name = "Classe")
    private String classe;

    public Semestre() {
    }

    public Semestre(Integer idSemestre) {
        this.idSemestre = idSemestre;
    }

    public Semestre(Integer idSemestre, String code, String libelleFr, int numero, boolean diplomant, String classe) {
        this.idSemestre = idSemestre;
        this.code = code;
        this.libelleFr = libelleFr;
        this.numero = numero;
        this.diplomant = diplomant;
        this.classe = classe;
    }

    public Integer getIdSemestre() {
        return idSemestre;
    }

    public void setIdSemestre(Integer idSemestre) {
        this.idSemestre = idSemestre;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public boolean getDiplomant() {
        return diplomant;
    }

    public void setDiplomant(boolean diplomant) {
        this.diplomant = diplomant;
    }

    public String getClasse() {
        return classe;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idSemestre != null ? idSemestre.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Semestre)) {
            return false;
        }
        Semestre other = (Semestre) object;
        if ((this.idSemestre == null && other.idSemestre != null) || (this.idSemestre != null && !this.idSemestre.equals(other.idSemestre))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Semestre[ idSemestre=" + idSemestre + " ]";
    }
    
}
