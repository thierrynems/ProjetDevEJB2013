/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "etablissement")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Etablissement.findAll", query = "SELECT e FROM Etablissement e"),
    @NamedQuery(name = "Etablissement.findByIdEtablissement", query = "SELECT e FROM Etablissement e WHERE e.idEtablissement = :idEtablissement"),
    @NamedQuery(name = "Etablissement.findByIdUniversite", query = "SELECT e FROM Etablissement e WHERE e.idUniversite = :idUniversite"),
    @NamedQuery(name = "Etablissement.findByCodeetab", query = "SELECT e FROM Etablissement e WHERE e.codeetab = :codeetab"),
    @NamedQuery(name = "Etablissement.findByNometabFr", query = "SELECT e FROM Etablissement e WHERE e.nometabFr = :nometabFr"),
    @NamedQuery(name = "Etablissement.findByNometabEn", query = "SELECT e FROM Etablissement e WHERE e.nometabEn = :nometabEn"),
    @NamedQuery(name = "Etablissement.findByTelephone", query = "SELECT e FROM Etablissement e WHERE e.telephone = :telephone"),
    @NamedQuery(name = "Etablissement.findBySiteweb", query = "SELECT e FROM Etablissement e WHERE e.siteweb = :siteweb"),
    @NamedQuery(name = "Etablissement.findByLogo", query = "SELECT e FROM Etablissement e WHERE e.logo = :logo"),
    @NamedQuery(name = "Etablissement.findByEtabcourant", query = "SELECT e FROM Etablissement e WHERE e.etabcourant = :etabcourant")})
public class Etablissement implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idEtablissement")
    private Integer idEtablissement;
    @Basic(optional = false)
    @Column(name = "idUniversite")
    private int idUniversite;
    @Basic(optional = false)
    @Column(name = "codeetab")
    private String codeetab;
    @Basic(optional = false)
    @Column(name = "nometab_fr")
    private String nometabFr;
    @Basic(optional = false)
    @Column(name = "nometab_en")
    private String nometabEn;
    @Basic(optional = false)
    @Lob
    @Column(name = "adresseetab")
    private String adresseetab;
    @Basic(optional = false)
    @Column(name = "telephone")
    private String telephone;
    @Basic(optional = false)
    @Column(name = "siteweb")
    private String siteweb;
    @Basic(optional = false)
    @Column(name = "logo")
    private String logo;
    @Basic(optional = false)
    @Column(name = "etabcourant")
    private boolean etabcourant;

    public Etablissement() {
    }

    public Etablissement(Integer idEtablissement) {
        this.idEtablissement = idEtablissement;
    }

    public Etablissement(Integer idEtablissement, int idUniversite, String codeetab, String nometabFr, String nometabEn, String adresseetab, String telephone, String siteweb, String logo, boolean etabcourant) {
        this.idEtablissement = idEtablissement;
        this.idUniversite = idUniversite;
        this.codeetab = codeetab;
        this.nometabFr = nometabFr;
        this.nometabEn = nometabEn;
        this.adresseetab = adresseetab;
        this.telephone = telephone;
        this.siteweb = siteweb;
        this.logo = logo;
        this.etabcourant = etabcourant;
    }

    public Integer getIdEtablissement() {
        return idEtablissement;
    }

    public void setIdEtablissement(Integer idEtablissement) {
        this.idEtablissement = idEtablissement;
    }

    public int getIdUniversite() {
        return idUniversite;
    }

    public void setIdUniversite(int idUniversite) {
        this.idUniversite = idUniversite;
    }

    public String getCodeetab() {
        return codeetab;
    }

    public void setCodeetab(String codeetab) {
        this.codeetab = codeetab;
    }

    public String getNometabFr() {
        return nometabFr;
    }

    public void setNometabFr(String nometabFr) {
        this.nometabFr = nometabFr;
    }

    public String getNometabEn() {
        return nometabEn;
    }

    public void setNometabEn(String nometabEn) {
        this.nometabEn = nometabEn;
    }

    public String getAdresseetab() {
        return adresseetab;
    }

    public void setAdresseetab(String adresseetab) {
        this.adresseetab = adresseetab;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getSiteweb() {
        return siteweb;
    }

    public void setSiteweb(String siteweb) {
        this.siteweb = siteweb;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public boolean getEtabcourant() {
        return etabcourant;
    }

    public void setEtabcourant(boolean etabcourant) {
        this.etabcourant = etabcourant;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idEtablissement != null ? idEtablissement.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Etablissement)) {
            return false;
        }
        Etablissement other = (Etablissement) object;
        if ((this.idEtablissement == null && other.idEtablissement != null) || (this.idEtablissement != null && !this.idEtablissement.equals(other.idEtablissement))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Etablissement[ idEtablissement=" + idEtablissement + " ]";
    }
    
}
