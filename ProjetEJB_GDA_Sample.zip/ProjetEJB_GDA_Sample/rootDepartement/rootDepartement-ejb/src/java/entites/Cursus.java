/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Thierrynems
 */
@Entity
@Table(name = "cursus")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Cursus.findAll", query = "SELECT c FROM Cursus c"),
    @NamedQuery(name = "Cursus.findByIdCursus", query = "SELECT c FROM Cursus c WHERE c.idCursus = :idCursus"),
    @NamedQuery(name = "Cursus.findByIddepartement", query = "SELECT c FROM Cursus c WHERE c.iddepartement = :iddepartement"),
    @NamedQuery(name = "Cursus.findByCodecursus", query = "SELECT c FROM Cursus c WHERE c.codecursus = :codecursus"),
    @NamedQuery(name = "Cursus.findByLibelleFr", query = "SELECT c FROM Cursus c WHERE c.libelleFr = :libelleFr"),
    @NamedQuery(name = "Cursus.findByLibelleEn", query = "SELECT c FROM Cursus c WHERE c.libelleEn = :libelleEn"),
    @NamedQuery(name = "Cursus.findByOrdre", query = "SELECT c FROM Cursus c WHERE c.ordre = :ordre")})
public class Cursus implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idCursus")
    private Integer idCursus;
    @Basic(optional = false)
    @Column(name = "iddepartement")
    private int iddepartement;
    @Basic(optional = false)
    @Column(name = "codecursus")
    private String codecursus;
    @Basic(optional = false)
    @Column(name = "libelle_fr")
    private String libelleFr;
    @Basic(optional = false)
    @Column(name = "libelle_en")
    private String libelleEn;
    @Basic(optional = false)
    @Column(name = "ordre")
    private int ordre;

    public Cursus() {
    }

    public Cursus(Integer idCursus) {
        this.idCursus = idCursus;
    }

    public Cursus(Integer idCursus, int iddepartement, String codecursus, String libelleFr, String libelleEn, int ordre) {
        this.idCursus = idCursus;
        this.iddepartement = iddepartement;
        this.codecursus = codecursus;
        this.libelleFr = libelleFr;
        this.libelleEn = libelleEn;
        this.ordre = ordre;
    }

    public Integer getIdCursus() {
        return idCursus;
    }

    public void setIdCursus(Integer idCursus) {
        this.idCursus = idCursus;
    }

    public int getIddepartement() {
        return iddepartement;
    }

    public void setIddepartement(int iddepartement) {
        this.iddepartement = iddepartement;
    }

    public String getCodecursus() {
        return codecursus;
    }

    public void setCodecursus(String codecursus) {
        this.codecursus = codecursus;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleEn() {
        return libelleEn;
    }

    public void setLibelleEn(String libelleEn) {
        this.libelleEn = libelleEn;
    }

    public int getOrdre() {
        return ordre;
    }

    public void setOrdre(int ordre) {
        this.ordre = ordre;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCursus != null ? idCursus.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cursus)) {
            return false;
        }
        Cursus other = (Cursus) object;
        if ((this.idCursus == null && other.idCursus != null) || (this.idCursus != null && !this.idCursus.equals(other.idCursus))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Cursus[ idCursus=" + idCursus + " ]";
    }
    
}
