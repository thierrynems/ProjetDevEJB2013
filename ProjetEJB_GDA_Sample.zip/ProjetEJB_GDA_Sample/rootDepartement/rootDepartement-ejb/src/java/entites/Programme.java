/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "programme")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Programme.findAll", query = "SELECT p FROM Programme p"),
    @NamedQuery(name = "Programme.findByIdProgramme", query = "SELECT p FROM Programme p WHERE p.idProgramme = :idProgramme"),
    @NamedQuery(name = "Programme.findByCodeprogramme", query = "SELECT p FROM Programme p WHERE p.codeprogramme = :codeprogramme"),
    @NamedQuery(name = "Programme.findByLibelleFr", query = "SELECT p FROM Programme p WHERE p.libelleFr = :libelleFr"),
    @NamedQuery(name = "Programme.findByLibelleEn", query = "SELECT p FROM Programme p WHERE p.libelleEn = :libelleEn"),
    @NamedQuery(name = "Programme.findByNbrecredit", query = "SELECT p FROM Programme p WHERE p.nbrecredit = :nbrecredit")})
public class Programme implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idProgramme")
    private Integer idProgramme;
    @Basic(optional = false)
    @Column(name = "codeprogramme")
    private String codeprogramme;
    @Basic(optional = false)
    @Column(name = "libelle_fr")
    private String libelleFr;
    @Basic(optional = false)
    @Column(name = "libelle_en")
    private String libelleEn;
    @Basic(optional = false)
    @Column(name = "nbrecredit")
    private int nbrecredit;

    public Programme() {
    }

    public Programme(Integer idProgramme) {
        this.idProgramme = idProgramme;
    }

    public Programme(Integer idProgramme, String codeprogramme, String libelleFr, String libelleEn, int nbrecredit) {
        this.idProgramme = idProgramme;
        this.codeprogramme = codeprogramme;
        this.libelleFr = libelleFr;
        this.libelleEn = libelleEn;
        this.nbrecredit = nbrecredit;
    }

    public Integer getIdProgramme() {
        return idProgramme;
    }

    public void setIdProgramme(Integer idProgramme) {
        this.idProgramme = idProgramme;
    }

    public String getCodeprogramme() {
        return codeprogramme;
    }

    public void setCodeprogramme(String codeprogramme) {
        this.codeprogramme = codeprogramme;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleEn() {
        return libelleEn;
    }

    public void setLibelleEn(String libelleEn) {
        this.libelleEn = libelleEn;
    }

    public int getNbrecredit() {
        return nbrecredit;
    }

    public void setNbrecredit(int nbrecredit) {
        this.nbrecredit = nbrecredit;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idProgramme != null ? idProgramme.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Programme)) {
            return false;
        }
        Programme other = (Programme) object;
        if ((this.idProgramme == null && other.idProgramme != null) || (this.idProgramme != null && !this.idProgramme.equals(other.idProgramme))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Programme[ idProgramme=" + idProgramme + " ]";
    }
    
}
