/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "optionsemestre")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Optionsemestre.findAll", query = "SELECT o FROM Optionsemestre o"),
    @NamedQuery(name = "Optionsemestre.findByIdoptionsemestre", query = "SELECT o FROM Optionsemestre o WHERE o.idoptionsemestre = :idoptionsemestre"),
    @NamedQuery(name = "Optionsemestre.findByIdSemestre", query = "SELECT o FROM Optionsemestre o WHERE o.idSemestre = :idSemestre"),
    @NamedQuery(name = "Optionsemestre.findByIdoptions", query = "SELECT o FROM Optionsemestre o WHERE o.idoptions = :idoptions")})
public class Optionsemestre implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idoptionsemestre")
    private Integer idoptionsemestre;
    @Basic(optional = false)
    @Column(name = "idSemestre")
    private int idSemestre;
    @Basic(optional = false)
    @Column(name = "idoptions")
    private int idoptions;

    public Optionsemestre() {
    }

    public Optionsemestre(Integer idoptionsemestre) {
        this.idoptionsemestre = idoptionsemestre;
    }

    public Optionsemestre(Integer idoptionsemestre, int idSemestre, int idoptions) {
        this.idoptionsemestre = idoptionsemestre;
        this.idSemestre = idSemestre;
        this.idoptions = idoptions;
    }

    public Integer getIdoptionsemestre() {
        return idoptionsemestre;
    }

    public void setIdoptionsemestre(Integer idoptionsemestre) {
        this.idoptionsemestre = idoptionsemestre;
    }

    public int getIdSemestre() {
        return idSemestre;
    }

    public void setIdSemestre(int idSemestre) {
        this.idSemestre = idSemestre;
    }

    public int getIdoptions() {
        return idoptions;
    }

    public void setIdoptions(int idoptions) {
        this.idoptions = idoptions;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idoptionsemestre != null ? idoptionsemestre.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Optionsemestre)) {
            return false;
        }
        Optionsemestre other = (Optionsemestre) object;
        if ((this.idoptionsemestre == null && other.idoptionsemestre != null) || (this.idoptionsemestre != null && !this.idoptionsemestre.equals(other.idoptionsemestre))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Optionsemestre[ idoptionsemestre=" + idoptionsemestre + " ]";
    }
    
}
