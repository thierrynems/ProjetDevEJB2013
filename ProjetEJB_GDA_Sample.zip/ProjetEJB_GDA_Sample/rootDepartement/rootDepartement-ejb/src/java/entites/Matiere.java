/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Thierrynems
 */
@Entity
@Table(name = "matiere")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Matiere.findAll", query = "SELECT m FROM Matiere m"),
    @NamedQuery(name = "Matiere.findByIdMatiere", query = "SELECT m FROM Matiere m WHERE m.idMatiere = :idMatiere"),
    @NamedQuery(name = "Matiere.findByCodematiere", query = "SELECT m FROM Matiere m WHERE m.codematiere = :codematiere"),
    @NamedQuery(name = "Matiere.findByLibelleFr", query = "SELECT m FROM Matiere m WHERE m.libelleFr = :libelleFr"),
    @NamedQuery(name = "Matiere.findByLibelleEn", query = "SELECT m FROM Matiere m WHERE m.libelleEn = :libelleEn")
})
/*******selection du programme adopte pour un semestre
 * @NamedQuery(name = "MatiereProgramme.findBySessionSemestre", query = "SELECT DISTINCT m.idmatiere,m.libelle_fr,m.libelle_en FROM matiere m JOIN matiereprogrammee mp ON mp.idmatiere=m.idmatiere WHERE mp.idoptionsemestre = :idoptionsemestre AND mp.idsession = :idsession")
 * SELECT * FROM programmeadopte pd JOIN programme p ON p.idprogramme=pd.idprogramme
JOIN ueprogramme up ON up.idprogramme=p.idprogramme
JOIN ue U ON u.idue=up.idue JOIN matiereue mu ON mu.idue=U.idue JOIN matiere m ON m.idmatiere=mu.idmatiere
 * */
public class Matiere implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idMatiere")
    private Integer idMatiere;
    @Basic(optional = false)
    @Column(name = "codematiere")
    private String codematiere;
    @Column(name = "libelle_fr")
    private String libelleFr;
    @Column(name = "libelle_en")
    private String libelleEn;

    public Matiere() {
    }

    public Matiere(Integer idMatiere) {
        this.idMatiere = idMatiere;
    }

    public Matiere(Integer idMatiere, String codematiere) {
        this.idMatiere = idMatiere;
        this.codematiere = codematiere;
    }

    public Integer getIdMatiere() {
        return idMatiere;
    }

    public void setIdMatiere(Integer idMatiere) {
        this.idMatiere = idMatiere;
    }

    public String getCodematiere() {
        return codematiere;
    }

    public void setCodematiere(String codematiere) {
        this.codematiere = codematiere;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleEn() {
        return libelleEn;
    }

    public void setLibelleEn(String libelleEn) {
        this.libelleEn = libelleEn;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idMatiere != null ? idMatiere.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Matiere)) {
            return false;
        }
        Matiere other = (Matiere) object;
        if ((this.idMatiere == null && other.idMatiere != null) || (this.idMatiere != null && !this.idMatiere.equals(other.idMatiere))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Matiere[ idMatiere=" + idMatiere + " ]";
    }
    
}
