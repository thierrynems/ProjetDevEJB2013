/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Thierrynems
 */
@Entity
@Table(name = "inscription")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Inscription.findAll", query = "SELECT i FROM Inscription i"),
    @NamedQuery(name = "Inscription.findByIdInscription", query = "SELECT i FROM Inscription i WHERE i.idInscription = :idInscription"),
    @NamedQuery(name = "Inscription.findByIdoptionsemestre", query = "SELECT i FROM Inscription i WHERE i.idoptionsemestre = :idoptionsemestre"),
    @NamedQuery(name = "Inscription.findByIdannee", query = "SELECT i FROM Inscription i WHERE i.idannee = :idannee"),
    @NamedQuery(name = "Inscription.findByIdEtudiant", query = "SELECT i FROM Inscription i WHERE i.idEtudiant = :idEtudiant"),
    @NamedQuery(name = "Inscription.findByIdoptions", query = "SELECT i FROM Inscription i WHERE i.idoptions = :idoptions"),
    @NamedQuery(name = "Inscription.findByIdcursus", query = "SELECT i FROM Inscription i WHERE i.idcursus = :idcursus"),
    @NamedQuery(name = "Inscription.findByCodeinscriptionamin", query = "SELECT i FROM Inscription i WHERE i.codeinscriptionamin = :codeinscriptionamin"),
    @NamedQuery(name = "Inscription.findByDateincriptionadmin", query = "SELECT i FROM Inscription i WHERE i.dateincriptionadmin = :dateincriptionadmin"),
    @NamedQuery(name = "Inscription.findByInscrit", query = "SELECT i FROM Inscription i WHERE i.inscrit = :inscrit")})
public class Inscription implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idInscription")
    private Integer idInscription;
    @Basic(optional = false)
    @Column(name = "idoptionsemestre")
    private int idoptionsemestre;
    @Basic(optional = false)
    @Column(name = "idannee")
    private int idannee;
    @Basic(optional = false)
    @Column(name = "idEtudiant")
    private int idEtudiant;
    @Column(name = "idoptions")
    private Integer idoptions;
    @Column(name = "idcursus")
    private Integer idcursus;
    @Basic(optional = false)
    @Column(name = "codeinscriptionamin")
    private String codeinscriptionamin;
    @Basic(optional = false)
    @Column(name = "dateincriptionadmin")
    @Temporal(TemporalType.DATE)
    private Date dateincriptionadmin;
    @Basic(optional = false)
    @Column(name = "inscrit")
    private boolean inscrit;

    public Inscription() {
    }

    public Inscription(Integer idInscription) {
        this.idInscription = idInscription;
    }

    public Inscription(Integer idInscription, int idoptionsemestre, int idannee, int idEtudiant, String codeinscriptionamin, Date dateincriptionadmin, boolean inscrit) {
        this.idInscription = idInscription;
        this.idoptionsemestre = idoptionsemestre;
        this.idannee = idannee;
        this.idEtudiant = idEtudiant;
        this.codeinscriptionamin = codeinscriptionamin;
        this.dateincriptionadmin = dateincriptionadmin;
        this.inscrit = inscrit;
    }

    public Integer getIdInscription() {
        return idInscription;
    }

    public void setIdInscription(Integer idInscription) {
        this.idInscription = idInscription;
    }

    public int getIdoptionsemestre() {
        return idoptionsemestre;
    }

    public void setIdoptionsemestre(int idoptionsemestre) {
        this.idoptionsemestre = idoptionsemestre;
    }

    public int getIdannee() {
        return idannee;
    }

    public void setIdannee(int idannee) {
        this.idannee = idannee;
    }

    public int getIdEtudiant() {
        return idEtudiant;
    }

    public void setIdEtudiant(int idEtudiant) {
        this.idEtudiant = idEtudiant;
    }

    public Integer getIdoptions() {
        return idoptions;
    }

    public void setIdoptions(Integer idoptions) {
        this.idoptions = idoptions;
    }

    public Integer getIdcursus() {
        return idcursus;
    }

    public void setIdcursus(Integer idcursus) {
        this.idcursus = idcursus;
    }

    public String getCodeinscriptionamin() {
        return codeinscriptionamin;
    }

    public void setCodeinscriptionamin(String codeinscriptionamin) {
        this.codeinscriptionamin = codeinscriptionamin;
    }

    public Date getDateincriptionadmin() {
        return dateincriptionadmin;
    }

    public void setDateincriptionadmin(Date dateincriptionadmin) {
        this.dateincriptionadmin = dateincriptionadmin;
    }

    public boolean getInscrit() {
        return inscrit;
    }

    public void setInscrit(boolean inscrit) {
        this.inscrit = inscrit;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idInscription != null ? idInscription.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Inscription)) {
            return false;
        }
        Inscription other = (Inscription) object;
        if ((this.idInscription == null && other.idInscription != null) || (this.idInscription != null && !this.idInscription.equals(other.idInscription))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Inscription[ idInscription=" + idInscription + " ]";
    }
    
}
