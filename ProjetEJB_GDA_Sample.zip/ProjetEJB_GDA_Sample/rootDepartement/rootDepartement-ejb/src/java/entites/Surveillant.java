/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "surveillant")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Surveillant.findAll", query = "SELECT s FROM Surveillant s"),
    @NamedQuery(name = "Surveillant.findByIdsurveillant", query = "SELECT s FROM Surveillant s WHERE s.idsurveillant = :idsurveillant"),
    @NamedQuery(name = "Surveillant.findByCodesurveillant", query = "SELECT s FROM Surveillant s WHERE s.codesurveillant = :codesurveillant"),
    @NamedQuery(name = "Surveillant.findByNomsurveillant", query = "SELECT s FROM Surveillant s WHERE s.nomsurveillant = :nomsurveillant"),
    @NamedQuery(name = "Surveillant.findByPrenomsurveillant", query = "SELECT s FROM Surveillant s WHERE s.prenomsurveillant = :prenomsurveillant"),
    @NamedQuery(name = "Surveillant.findByTelephone", query = "SELECT s FROM Surveillant s WHERE s.telephone = :telephone")})
public class Surveillant implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idsurveillant")
    private Integer idsurveillant;
    @Column(name = "codesurveillant")
    private String codesurveillant;
    @Column(name = "nomsurveillant")
    private String nomsurveillant;
    @Column(name = "prenomsurveillant")
    private String prenomsurveillant;
    @Column(name = "telephone")
    private String telephone;

    public Surveillant() {
    }

    public Surveillant(Integer idsurveillant) {
        this.idsurveillant = idsurveillant;
    }

    public Integer getIdsurveillant() {
        return idsurveillant;
    }

    public void setIdsurveillant(Integer idsurveillant) {
        this.idsurveillant = idsurveillant;
    }

    public String getCodesurveillant() {
        return codesurveillant;
    }

    public void setCodesurveillant(String codesurveillant) {
        this.codesurveillant = codesurveillant;
    }

    public String getNomsurveillant() {
        return nomsurveillant;
    }

    public void setNomsurveillant(String nomsurveillant) {
        this.nomsurveillant = nomsurveillant;
    }

    public String getPrenomsurveillant() {
        return prenomsurveillant;
    }

    public void setPrenomsurveillant(String prenomsurveillant) {
        this.prenomsurveillant = prenomsurveillant;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idsurveillant != null ? idsurveillant.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Surveillant)) {
            return false;
        }
        Surveillant other = (Surveillant) object;
        if ((this.idsurveillant == null && other.idsurveillant != null) || (this.idsurveillant != null && !this.idsurveillant.equals(other.idsurveillant))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Surveillant[ idsurveillant=" + idsurveillant + " ]";
    }
    
}
