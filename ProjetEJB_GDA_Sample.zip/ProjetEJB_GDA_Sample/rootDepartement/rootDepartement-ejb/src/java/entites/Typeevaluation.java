/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "typeevaluation")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Typeevaluation.findAll", query = "SELECT t FROM Typeevaluation t"),
    @NamedQuery(name = "Typeevaluation.findByIdtypeevaluation", query = "SELECT t FROM Typeevaluation t WHERE t.idtypeevaluation = :idtypeevaluation"),
    @NamedQuery(name = "Typeevaluation.findByCode", query = "SELECT t FROM Typeevaluation t WHERE t.code = :code"),
    @NamedQuery(name = "Typeevaluation.findByLibelleFr", query = "SELECT t FROM Typeevaluation t WHERE t.libelleFr = :libelleFr"),
    @NamedQuery(name = "Typeevaluation.findByLibelleEn", query = "SELECT t FROM Typeevaluation t WHERE t.libelleEn = :libelleEn")})
public class Typeevaluation implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idtypeevaluation")
    private Integer idtypeevaluation;
    @Basic(optional = false)
    @Column(name = "code")
    private String code;
    @Basic(optional = false)
    @Column(name = "libelle_fr")
    private String libelleFr;
    @Basic(optional = false)
    @Column(name = "libelle_en")
    private String libelleEn;

    public Typeevaluation() {
    }

    public Typeevaluation(Integer idtypeevaluation) {
        this.idtypeevaluation = idtypeevaluation;
    }

    public Typeevaluation(Integer idtypeevaluation, String code, String libelleFr, String libelleEn) {
        this.idtypeevaluation = idtypeevaluation;
        this.code = code;
        this.libelleFr = libelleFr;
        this.libelleEn = libelleEn;
    }

    public Integer getIdtypeevaluation() {
        return idtypeevaluation;
    }

    public void setIdtypeevaluation(Integer idtypeevaluation) {
        this.idtypeevaluation = idtypeevaluation;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleEn() {
        return libelleEn;
    }

    public void setLibelleEn(String libelleEn) {
        this.libelleEn = libelleEn;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idtypeevaluation != null ? idtypeevaluation.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Typeevaluation)) {
            return false;
        }
        Typeevaluation other = (Typeevaluation) object;
        if ((this.idtypeevaluation == null && other.idtypeevaluation != null) || (this.idtypeevaluation != null && !this.idtypeevaluation.equals(other.idtypeevaluation))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Typeevaluation[ idtypeevaluation=" + idtypeevaluation + " ]";
    }
    
}
