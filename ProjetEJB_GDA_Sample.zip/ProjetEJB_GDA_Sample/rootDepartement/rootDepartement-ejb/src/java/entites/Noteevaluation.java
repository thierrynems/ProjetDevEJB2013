/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Thierrynems
 */
@Entity
@Table(name = "noteevaluation")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Noteevaluation.findAll", query = "SELECT n FROM Noteevaluation n"),
    @NamedQuery(name = "Noteevaluation.findByIdnoteevaluation", query = "SELECT n FROM Noteevaluation n WHERE n.idnoteevaluation = :idnoteevaluation"),
    @NamedQuery(name = "Noteevaluation.findByIdEtudiant", query = "SELECT n FROM Noteevaluation n WHERE n.idEtudiant = :idEtudiant"),
    @NamedQuery(name = "Noteevaluation.findByIdoptionsemestre", query = "SELECT n FROM Noteevaluation n WHERE n.idoptionsemestre = :idoptionsemestre"),
    @NamedQuery(name = "Noteevaluation.findByIdSession", query = "SELECT n FROM Noteevaluation n WHERE n.idSession = :idSession"),
    @NamedQuery(name = "Noteevaluation.findByIdMatiere", query = "SELECT n FROM Noteevaluation n WHERE n.idMatiere = :idMatiere"),
    @NamedQuery(name = "Noteevaluation.findByIdevaluation", query = "SELECT n FROM Noteevaluation n WHERE n.idevaluation = :idevaluation"),
    @NamedQuery(name = "Noteevaluation.findByIdoptions", query = "SELECT n FROM Noteevaluation n WHERE n.idoptions = :idoptions"),
    @NamedQuery(name = "Noteevaluation.findByNotecc", query = "SELECT n FROM Noteevaluation n WHERE n.notecc = :notecc"),
    @NamedQuery(name = "Noteevaluation.findByNotetp", query = "SELECT n FROM Noteevaluation n WHERE n.notetp = :notetp"),
    @NamedQuery(name = "Noteevaluation.findByNoteex", query = "SELECT n FROM Noteevaluation n WHERE n.noteex = :noteex"),
    @NamedQuery(name = "Noteevaluation.findByNotefinale", query = "SELECT n FROM Noteevaluation n WHERE n.notefinale = :notefinale"),
    @NamedQuery(name = "Noteevaluation.findByObservation", query = "SELECT n FROM Noteevaluation n WHERE n.observation = :observation"),
    @NamedQuery(name = "Noteevaluation.findByAnonymat", query = "SELECT n FROM Noteevaluation n WHERE n.anonymat = :anonymat"),
    @NamedQuery(name = "Noteevaluation.findnote", query = "SELECT n FROM Noteevaluation n WHERE n.idEtudiant = :idEtudiant AND n.idoptionsemestre = :idoptionsemestre AND n.idSession = :idSession AND n.idoptions = :idoptions AND n.idMatiere = :idMatiere "),
    @NamedQuery(name = "Noteevaluation.findByAnonymatAndEvaluation", query = "SELECT n FROM Noteevaluation n WHERE n.anonymat = :anonymat AND n.idoptionsemestre = :idoptionsemestre AND n.idMatiere = :idMatiere  AND n.idoptions = :idoptions AND n.idSession = :idSession")
})
public class Noteevaluation implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idnoteevaluation")
    private Integer idnoteevaluation;
    @Basic(optional = false)
    @Column(name = "idEtudiant")
    private int idEtudiant;
    @Basic(optional = false)
    @Column(name = "idoptionsemestre")
    private int idoptionsemestre;
    @Basic(optional = false)
    @Column(name = "idSession")
    private int idSession;
    @Basic(optional = false)
    @Column(name = "idMatiere")
    private int idMatiere;
    @Basic(optional = false)
    @Column(name = "idevaluation")
    private int idevaluation;
    @Basic(optional = false)
    @Column(name = "idoptions")
    private int idoptions;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "notecc")
    private Float notecc;
    @Column(name = "notetp")
    private Float notetp;
    @Column(name = "noteex")
    private Float noteex;
    @Column(name = "notefinale")
    private Float notefinale;
    @Column(name = "observation")
    private String observation;
    @Column(name = "anonymat")
    private String anonymat;

    public Noteevaluation() {
    }

    public Noteevaluation(Integer idnoteevaluation) {
        this.idnoteevaluation = idnoteevaluation;
    }

    public Noteevaluation(Integer idnoteevaluation, int idEtudiant, int idoptionsemestre, int idSession, int idMatiere, int idevaluation, int idoptions) {
        this.idnoteevaluation = idnoteevaluation;
        this.idEtudiant = idEtudiant;
        this.idoptionsemestre = idoptionsemestre;
        this.idSession = idSession;
        this.idMatiere = idMatiere;
        this.idevaluation = idevaluation;
        this.idoptions = idoptions;
    }

    public Integer getIdnoteevaluation() {
        return idnoteevaluation;
    }

    public void setIdnoteevaluation(Integer idnoteevaluation) {
        this.idnoteevaluation = idnoteevaluation;
    }

    public int getIdEtudiant() {
        return idEtudiant;
    }

    public void setIdEtudiant(int idEtudiant) {
        this.idEtudiant = idEtudiant;
    }

    public int getIdoptionsemestre() {
        return idoptionsemestre;
    }

    public void setIdoptionsemestre(int idoptionsemestre) {
        this.idoptionsemestre = idoptionsemestre;
    }

    public int getIdSession() {
        return idSession;
    }

    public void setIdSession(int idSession) {
        this.idSession = idSession;
    }

    public int getIdMatiere() {
        return idMatiere;
    }

    public void setIdMatiere(int idMatiere) {
        this.idMatiere = idMatiere;
    }

    public int getIdevaluation() {
        return idevaluation;
    }

    public void setIdevaluation(int idevaluation) {
        this.idevaluation = idevaluation;
    }

    public int getIdoptions() {
        return idoptions;
    }

    public void setIdoptions(int idoptions) {
        this.idoptions = idoptions;
    }

    public Float getNotecc() {
        return notecc;
    }

    public void setNotecc(Float notecc) {
        this.notecc = notecc;
    }

    public Float getNotetp() {
        return notetp;
    }

    public void setNotetp(Float notetp) {
        this.notetp = notetp;
    }

    public Float getNoteex() {
        return noteex;
    }

    public void setNoteex(Float noteex) {
        this.noteex = noteex;
    }

    public Float getNotefinale() {
        return notefinale;
    }

    public void setNotefinale(Float notefinale) {
        this.notefinale = notefinale;
    }

    public String getObservation() {
        return observation;
    }

    public void setObservation(String observation) {
        this.observation = observation;
    }

    public String getAnonymat() {
        return anonymat;
    }

    public void setAnonymat(String anonymat) {
        this.anonymat = anonymat;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idnoteevaluation != null ? idnoteevaluation.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Noteevaluation)) {
            return false;
        }
        Noteevaluation other = (Noteevaluation) object;
        if ((this.idnoteevaluation == null && other.idnoteevaluation != null) || (this.idnoteevaluation != null && !this.idnoteevaluation.equals(other.idnoteevaluation))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Noteevaluation[ idnoteevaluation=" + idnoteevaluation + " ]";
    }
    
}
