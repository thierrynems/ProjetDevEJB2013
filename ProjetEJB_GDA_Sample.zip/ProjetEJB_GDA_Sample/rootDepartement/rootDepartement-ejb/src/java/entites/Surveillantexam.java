/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "surveillantexam")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Surveillantexam.findAll", query = "SELECT s FROM Surveillantexam s"),
    @NamedQuery(name = "Surveillantexam.findByIdsurveillantexam", query = "SELECT s FROM Surveillantexam s WHERE s.idsurveillantexam = :idsurveillantexam"),
    @NamedQuery(name = "Surveillantexam.findByIdsurveillant", query = "SELECT s FROM Surveillantexam s WHERE s.idsurveillant = :idsurveillant"),
    @NamedQuery(name = "Surveillantexam.findByIdMatiereProgrammee", query = "SELECT s FROM Surveillantexam s WHERE s.idMatiereProgrammee = :idMatiereProgrammee")})
public class Surveillantexam implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idsurveillantexam")
    private Integer idsurveillantexam;
    @Basic(optional = false)
    @Column(name = "idsurveillant")
    private int idsurveillant;
    @Basic(optional = false)
    @Column(name = "idMatiereProgrammee")
    private int idMatiereProgrammee;

    public Surveillantexam() {
    }

    public Surveillantexam(Integer idsurveillantexam) {
        this.idsurveillantexam = idsurveillantexam;
    }

    public Surveillantexam(Integer idsurveillantexam, int idsurveillant, int idMatiereProgrammee) {
        this.idsurveillantexam = idsurveillantexam;
        this.idsurveillant = idsurveillant;
        this.idMatiereProgrammee = idMatiereProgrammee;
    }

    public Integer getIdsurveillantexam() {
        return idsurveillantexam;
    }

    public void setIdsurveillantexam(Integer idsurveillantexam) {
        this.idsurveillantexam = idsurveillantexam;
    }

    public int getIdsurveillant() {
        return idsurveillant;
    }

    public void setIdsurveillant(int idsurveillant) {
        this.idsurveillant = idsurveillant;
    }

    public int getIdMatiereProgrammee() {
        return idMatiereProgrammee;
    }

    public void setIdMatiereProgrammee(int idMatiereProgrammee) {
        this.idMatiereProgrammee = idMatiereProgrammee;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idsurveillantexam != null ? idsurveillantexam.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Surveillantexam)) {
            return false;
        }
        Surveillantexam other = (Surveillantexam) object;
        if ((this.idsurveillantexam == null && other.idsurveillantexam != null) || (this.idsurveillantexam != null && !this.idsurveillantexam.equals(other.idsurveillantexam))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Surveillantexam[ idsurveillantexam=" + idsurveillantexam + " ]";
    }
    
}
