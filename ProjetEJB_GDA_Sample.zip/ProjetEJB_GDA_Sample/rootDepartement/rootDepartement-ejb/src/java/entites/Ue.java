/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Thierrynems
 */
@Entity
@Table(name = "ue")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Ue.findAll", query = "SELECT u FROM Ue u"),
    @NamedQuery(name = "Ue.findByIdue", query = "SELECT u FROM Ue u WHERE u.idue = :idue"),
    @NamedQuery(name = "Ue.findByCodeue", query = "SELECT u FROM Ue u WHERE u.codeue = :codeue"),
    @NamedQuery(name = "Ue.findByLibelleFr", query = "SELECT u FROM Ue u WHERE u.libelleFr = :libelleFr"),
    @NamedQuery(name = "Ue.findByLibelleEn", query = "SELECT u FROM Ue u WHERE u.libelleEn = :libelleEn"),
    @NamedQuery(name = "Ue.findByMoyvalide", query = "SELECT u FROM Ue u WHERE u.moyvalide = :moyvalide"),
    @NamedQuery(name = "Ue.findByNbrecredit", query = "SELECT u FROM Ue u WHERE u.nbrecredit = :nbrecredit"),
    @NamedQuery(name = "Ue.findByTypeue", query = "SELECT u FROM Ue u WHERE u.typeue = :typeue"),
    @NamedQuery(name = "Ue.findByNbrematiereue", query = "SELECT u FROM Ue u WHERE u.nbrematiereue = :nbrematiereue"),
    @NamedQuery(name = "Ue.findByNbrematierechoisie", query = "SELECT u FROM Ue u WHERE u.nbrematierechoisie = :nbrematierechoisie"),
    @NamedQuery(name = "Ue.findByNbrematopchoisie", query = "SELECT u FROM Ue u WHERE u.nbrematopchoisie = :nbrematopchoisie"),
    @NamedQuery(name = "Ue.findByNbrecredittotalmatop", query = "SELECT u FROM Ue u WHERE u.nbrecredittotalmatop = :nbrecredittotalmatop")})
public class Ue implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idue")
    private Integer idue;
    @Basic(optional = false)
    @Column(name = "codeue")
    private String codeue;
    @Basic(optional = false)
    @Column(name = "libelle_fr")
    private String libelleFr;
    @Basic(optional = false)
    @Column(name = "libelle_en")
    private String libelleEn;
    @Basic(optional = false)
    @Column(name = "moyvalide")
    private float moyvalide;
    @Basic(optional = false)
    @Column(name = "nbrecredit")
    private short nbrecredit;
    @Basic(optional = false)
    @Column(name = "typeue")
    private String typeue;
    @Column(name = "nbrematiereue")
    private Integer nbrematiereue;
    @Column(name = "nbrematierechoisie")
    private Integer nbrematierechoisie;
    @Column(name = "nbrematopchoisie")
    private Integer nbrematopchoisie;
    @Column(name = "nbrecredittotalmatop")
    private Integer nbrecredittotalmatop;

    public Ue() {
    }

    public Ue(Integer idue) {
        this.idue = idue;
    }

    public Ue(Integer idue, String codeue, String libelleFr, String libelleEn, float moyvalide, short nbrecredit, String typeue) {
        this.idue = idue;
        this.codeue = codeue;
        this.libelleFr = libelleFr;
        this.libelleEn = libelleEn;
        this.moyvalide = moyvalide;
        this.nbrecredit = nbrecredit;
        this.typeue = typeue;
    }

    public Integer getIdue() {
        return idue;
    }

    public void setIdue(Integer idue) {
        this.idue = idue;
    }

    public String getCodeue() {
        return codeue;
    }

    public void setCodeue(String codeue) {
        this.codeue = codeue;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleEn() {
        return libelleEn;
    }

    public void setLibelleEn(String libelleEn) {
        this.libelleEn = libelleEn;
    }

    public float getMoyvalide() {
        return moyvalide;
    }

    public void setMoyvalide(float moyvalide) {
        this.moyvalide = moyvalide;
    }

    public short getNbrecredit() {
        return nbrecredit;
    }

    public void setNbrecredit(short nbrecredit) {
        this.nbrecredit = nbrecredit;
    }

    public String getTypeue() {
        return typeue;
    }

    public void setTypeue(String typeue) {
        this.typeue = typeue;
    }

    public Integer getNbrematiereue() {
        return nbrematiereue;
    }

    public void setNbrematiereue(Integer nbrematiereue) {
        this.nbrematiereue = nbrematiereue;
    }

    public Integer getNbrematierechoisie() {
        return nbrematierechoisie;
    }

    public void setNbrematierechoisie(Integer nbrematierechoisie) {
        this.nbrematierechoisie = nbrematierechoisie;
    }

    public Integer getNbrematopchoisie() {
        return nbrematopchoisie;
    }

    public void setNbrematopchoisie(Integer nbrematopchoisie) {
        this.nbrematopchoisie = nbrematopchoisie;
    }

    public Integer getNbrecredittotalmatop() {
        return nbrecredittotalmatop;
    }

    public void setNbrecredittotalmatop(Integer nbrecredittotalmatop) {
        this.nbrecredittotalmatop = nbrecredittotalmatop;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idue != null ? idue.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ue)) {
            return false;
        }
        Ue other = (Ue) object;
        if ((this.idue == null && other.idue != null) || (this.idue != null && !this.idue.equals(other.idue))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Ue[ idue=" + idue + " ]";
    }
    
}
