/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "minuite")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Minuite.findAll", query = "SELECT m FROM Minuite m"),
    @NamedQuery(name = "Minuite.findByIdminuite", query = "SELECT m FROM Minuite m WHERE m.idminuite = :idminuite"),
    @NamedQuery(name = "Minuite.findByCode", query = "SELECT m FROM Minuite m WHERE m.code = :code"),
    @NamedQuery(name = "Minuite.findByLibelleFr", query = "SELECT m FROM Minuite m WHERE m.libelleFr = :libelleFr"),
    @NamedQuery(name = "Minuite.findByLibelleEn", query = "SELECT m FROM Minuite m WHERE m.libelleEn = :libelleEn")})
public class Minuite implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idminuite")
    private Integer idminuite;
    @Column(name = "code")
    private String code;
    @Column(name = "libelle_fr")
    private String libelleFr;
    @Column(name = "libelle_en")
    private String libelleEn;

    public Minuite() {
    }

    public Minuite(Integer idminuite) {
        this.idminuite = idminuite;
    }

    public Integer getIdminuite() {
        return idminuite;
    }

    public void setIdminuite(Integer idminuite) {
        this.idminuite = idminuite;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleEn() {
        return libelleEn;
    }

    public void setLibelleEn(String libelleEn) {
        this.libelleEn = libelleEn;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idminuite != null ? idminuite.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Minuite)) {
            return false;
        }
        Minuite other = (Minuite) object;
        if ((this.idminuite == null && other.idminuite != null) || (this.idminuite != null && !this.idminuite.equals(other.idminuite))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Minuite[ idminuite=" + idminuite + " ]";
    }
    
}
