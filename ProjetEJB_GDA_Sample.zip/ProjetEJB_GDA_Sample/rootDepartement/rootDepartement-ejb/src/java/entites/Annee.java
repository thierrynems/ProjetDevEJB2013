/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Thierrynems
 */
@Entity
@Table(name = "annee")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Annee.findAll", query = "SELECT a FROM Annee a"),
    @NamedQuery(name = "Annee.findByIdannee", query = "SELECT a FROM Annee a WHERE a.idannee = :idannee"),
    @NamedQuery(name = "Annee.findByCode", query = "SELECT a FROM Annee a WHERE a.code = :code"),
    @NamedQuery(name = "Annee.findByLibelleFr", query = "SELECT a FROM Annee a WHERE a.libelleFr = :libelleFr"),
    @NamedQuery(name = "Annee.findByLibelleEn", query = "SELECT a FROM Annee a WHERE a.libelleEn = :libelleEn"),
    @NamedQuery(name = "Annee.findByEncours", query = "SELECT a FROM Annee a WHERE a.encours = :encours"),
    @NamedQuery(name = "Annee.findByOrdre", query = "SELECT a FROM Annee a WHERE a.ordre = :ordre")})
public class Annee implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idannee")
    private Integer idannee;
    @Basic(optional = false)
    @Column(name = "code")
    private String code;
    @Basic(optional = false)
    @Column(name = "libelle_fr")
    private String libelleFr;
    @Basic(optional = false)
    @Column(name = "libelle_en")
    private String libelleEn;
    @Basic(optional = false)
    @Column(name = "encours")
    private boolean encours;
    @Basic(optional = false)
    @Column(name = "ordre")
    private int ordre;

    public Annee() {
    }

    public Annee(Integer idannee) {
        this.idannee = idannee;
    }

    public Annee(Integer idannee, String code, String libelleFr, String libelleEn, boolean encours, int ordre) {
        this.idannee = idannee;
        this.code = code;
        this.libelleFr = libelleFr;
        this.libelleEn = libelleEn;
        this.encours = encours;
        this.ordre = ordre;
    }

    public Integer getIdannee() {
        return idannee;
    }

    public void setIdannee(Integer idannee) {
        this.idannee = idannee;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleEn() {
        return libelleEn;
    }

    public void setLibelleEn(String libelleEn) {
        this.libelleEn = libelleEn;
    }

    public boolean getEncours() {
        return encours;
    }

    public void setEncours(boolean encours) {
        this.encours = encours;
    }

    public int getOrdre() {
        return ordre;
    }

    public void setOrdre(int ordre) {
        this.ordre = ordre;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idannee != null ? idannee.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Annee)) {
            return false;
        }
        Annee other = (Annee) object;
        if ((this.idannee == null && other.idannee != null) || (this.idannee != null && !this.idannee.equals(other.idannee))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Annee[ idannee=" + idannee + " ]";
    }
    
}
