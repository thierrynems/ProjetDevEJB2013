/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "enseignant")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Enseignant.findAll", query = "SELECT e FROM Enseignant e"),
    @NamedQuery(name = "Enseignant.findByIdEnseignant", query = "SELECT e FROM Enseignant e WHERE e.idEnseignant = :idEnseignant"),
    @NamedQuery(name = "Enseignant.findByIdusers", query = "SELECT e FROM Enseignant e WHERE e.idusers = :idusers"),
    @NamedQuery(name = "Enseignant.findByIddepartement", query = "SELECT e FROM Enseignant e WHERE e.iddepartement = :iddepartement"),
    @NamedQuery(name = "Enseignant.findByMatriculeeng", query = "SELECT e FROM Enseignant e WHERE e.matriculeeng = :matriculeeng"),
    @NamedQuery(name = "Enseignant.findByCodeenseignant", query = "SELECT e FROM Enseignant e WHERE e.codeenseignant = :codeenseignant"),
    @NamedQuery(name = "Enseignant.findByNomenseig", query = "SELECT e FROM Enseignant e WHERE e.nomenseig = :nomenseig"),
    @NamedQuery(name = "Enseignant.findByPrenomenseig", query = "SELECT e FROM Enseignant e WHERE e.prenomenseig = :prenomenseig"),
    @NamedQuery(name = "Enseignant.findByDatenaiss", query = "SELECT e FROM Enseignant e WHERE e.datenaiss = :datenaiss"),
    @NamedQuery(name = "Enseignant.findByLieunaiss", query = "SELECT e FROM Enseignant e WHERE e.lieunaiss = :lieunaiss"),
    @NamedQuery(name = "Enseignant.findByPhoto", query = "SELECT e FROM Enseignant e WHERE e.photo = :photo"),
    @NamedQuery(name = "Enseignant.findBySexe", query = "SELECT e FROM Enseignant e WHERE e.sexe = :sexe"),
    @NamedQuery(name = "Enseignant.findBySpecialite", query = "SELECT e FROM Enseignant e WHERE e.specialite = :specialite"),
    @NamedQuery(name = "Enseignant.findByGrade", query = "SELECT e FROM Enseignant e WHERE e.grade = :grade"),
    @NamedQuery(name = "Enseignant.findByTitre", query = "SELECT e FROM Enseignant e WHERE e.titre = :titre"),
    @NamedQuery(name = "Enseignant.findByCivilite", query = "SELECT e FROM Enseignant e WHERE e.civilite = :civilite"),
    @NamedQuery(name = "Enseignant.findByCategorieenseig", query = "SELECT e FROM Enseignant e WHERE e.categorieenseig = :categorieenseig")})
public class Enseignant implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idEnseignant")
    private Integer idEnseignant;
    @Basic(optional = false)
    @Column(name = "idusers")
    private int idusers;
    @Basic(optional = false)
    @Column(name = "iddepartement")
    private int iddepartement;
    @Basic(optional = false)
    @Column(name = "matriculeeng")
    private String matriculeeng;
    @Basic(optional = false)
    @Column(name = "codeenseignant")
    private String codeenseignant;
    @Basic(optional = false)
    @Column(name = "nomenseig")
    private String nomenseig;
    @Basic(optional = false)
    @Column(name = "prenomenseig")
    private String prenomenseig;
    @Basic(optional = false)
    @Column(name = "datenaiss")
    @Temporal(TemporalType.DATE)
    private Date datenaiss;
    @Basic(optional = false)
    @Column(name = "lieunaiss")
    private String lieunaiss;
    @Basic(optional = false)
    @Column(name = "photo")
    private String photo;
    @Basic(optional = false)
    @Column(name = "sexe")
    private String sexe;
    @Basic(optional = false)
    @Column(name = "specialite")
    private String specialite;
    @Basic(optional = false)
    @Column(name = "grade")
    private String grade;
    @Basic(optional = false)
    @Column(name = "titre")
    private String titre;
    @Basic(optional = false)
    @Column(name = "civilite")
    private String civilite;
    @Basic(optional = false)
    @Column(name = "categorieenseig")
    private String categorieenseig;

    public Enseignant() {
    }

    public Enseignant(Integer idEnseignant) {
        this.idEnseignant = idEnseignant;
    }

    public Enseignant(Integer idEnseignant, int idusers, int iddepartement, String matriculeeng, String codeenseignant, String nomenseig, String prenomenseig, Date datenaiss, String lieunaiss, String photo, String sexe, String specialite, String grade, String titre, String civilite, String categorieenseig) {
        this.idEnseignant = idEnseignant;
        this.idusers = idusers;
        this.iddepartement = iddepartement;
        this.matriculeeng = matriculeeng;
        this.codeenseignant = codeenseignant;
        this.nomenseig = nomenseig;
        this.prenomenseig = prenomenseig;
        this.datenaiss = datenaiss;
        this.lieunaiss = lieunaiss;
        this.photo = photo;
        this.sexe = sexe;
        this.specialite = specialite;
        this.grade = grade;
        this.titre = titre;
        this.civilite = civilite;
        this.categorieenseig = categorieenseig;
    }

    public Integer getIdEnseignant() {
        return idEnseignant;
    }

    public void setIdEnseignant(Integer idEnseignant) {
        this.idEnseignant = idEnseignant;
    }

    public int getIdusers() {
        return idusers;
    }

    public void setIdusers(int idusers) {
        this.idusers = idusers;
    }

    public int getIddepartement() {
        return iddepartement;
    }

    public void setIddepartement(int iddepartement) {
        this.iddepartement = iddepartement;
    }

    public String getMatriculeeng() {
        return matriculeeng;
    }

    public void setMatriculeeng(String matriculeeng) {
        this.matriculeeng = matriculeeng;
    }

    public String getCodeenseignant() {
        return codeenseignant;
    }

    public void setCodeenseignant(String codeenseignant) {
        this.codeenseignant = codeenseignant;
    }

    public String getNomenseig() {
        return nomenseig;
    }

    public void setNomenseig(String nomenseig) {
        this.nomenseig = nomenseig;
    }

    public String getPrenomenseig() {
        return prenomenseig;
    }

    public void setPrenomenseig(String prenomenseig) {
        this.prenomenseig = prenomenseig;
    }

    public Date getDatenaiss() {
        return datenaiss;
    }

    public void setDatenaiss(Date datenaiss) {
        this.datenaiss = datenaiss;
    }

    public String getLieunaiss() {
        return lieunaiss;
    }

    public void setLieunaiss(String lieunaiss) {
        this.lieunaiss = lieunaiss;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getSexe() {
        return sexe;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public String getSpecialite() {
        return specialite;
    }

    public void setSpecialite(String specialite) {
        this.specialite = specialite;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getCivilite() {
        return civilite;
    }

    public void setCivilite(String civilite) {
        this.civilite = civilite;
    }

    public String getCategorieenseig() {
        return categorieenseig;
    }

    public void setCategorieenseig(String categorieenseig) {
        this.categorieenseig = categorieenseig;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idEnseignant != null ? idEnseignant.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Enseignant)) {
            return false;
        }
        Enseignant other = (Enseignant) object;
        if ((this.idEnseignant == null && other.idEnseignant != null) || (this.idEnseignant != null && !this.idEnseignant.equals(other.idEnseignant))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Enseignant[ idEnseignant=" + idEnseignant + " ]";
    }
    
}
