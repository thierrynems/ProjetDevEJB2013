/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "groupuser")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Groupuser.findAll", query = "SELECT g FROM Groupuser g"),
    @NamedQuery(name = "Groupuser.findByIdgroupuser", query = "SELECT g FROM Groupuser g WHERE g.idgroupuser = :idgroupuser"),
    @NamedQuery(name = "Groupuser.findByCode", query = "SELECT g FROM Groupuser g WHERE g.code = :code"),
    @NamedQuery(name = "Groupuser.findByLibelleFr", query = "SELECT g FROM Groupuser g WHERE g.libelleFr = :libelleFr"),
    @NamedQuery(name = "Groupuser.findByLibelleEn", query = "SELECT g FROM Groupuser g WHERE g.libelleEn = :libelleEn")})
public class Groupuser implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idgroupuser")
    private Integer idgroupuser;
    @Column(name = "code")
    private String code;
    @Column(name = "libelle_fr")
    private String libelleFr;
    @Column(name = "libelle_en")
    private String libelleEn;

    public Groupuser() {
    }

    public Groupuser(Integer idgroupuser) {
        this.idgroupuser = idgroupuser;
    }

    public Integer getIdgroupuser() {
        return idgroupuser;
    }

    public void setIdgroupuser(Integer idgroupuser) {
        this.idgroupuser = idgroupuser;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleEn() {
        return libelleEn;
    }

    public void setLibelleEn(String libelleEn) {
        this.libelleEn = libelleEn;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idgroupuser != null ? idgroupuser.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Groupuser)) {
            return false;
        }
        Groupuser other = (Groupuser) object;
        if ((this.idgroupuser == null && other.idgroupuser != null) || (this.idgroupuser != null && !this.idgroupuser.equals(other.idgroupuser))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Groupuser[ idgroupuser=" + idgroupuser + " ]";
    }
    
}
