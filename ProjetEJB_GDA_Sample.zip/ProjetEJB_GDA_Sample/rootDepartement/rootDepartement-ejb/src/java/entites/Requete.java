/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "requete")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Requete.findAll", query = "SELECT r FROM Requete r"),
    @NamedQuery(name = "Requete.findByIdrequete", query = "SELECT r FROM Requete r WHERE r.idrequete = :idrequete"),
    @NamedQuery(name = "Requete.findByIdEtudiant", query = "SELECT r FROM Requete r WHERE r.idEtudiant = :idEtudiant"),
    @NamedQuery(name = "Requete.findByIdSession", query = "SELECT r FROM Requete r WHERE r.idSession = :idSession"),
    @NamedQuery(name = "Requete.findByIdoptionsemestre", query = "SELECT r FROM Requete r WHERE r.idoptionsemestre = :idoptionsemestre"),
    @NamedQuery(name = "Requete.findByIdMatiere", query = "SELECT r FROM Requete r WHERE r.idMatiere = :idMatiere"),
    @NamedQuery(name = "Requete.findByCode", query = "SELECT r FROM Requete r WHERE r.code = :code"),
    @NamedQuery(name = "Requete.findByNoteccav", query = "SELECT r FROM Requete r WHERE r.noteccav = :noteccav"),
    @NamedQuery(name = "Requete.findByNotetpav", query = "SELECT r FROM Requete r WHERE r.notetpav = :notetpav"),
    @NamedQuery(name = "Requete.findByNoteexav", query = "SELECT r FROM Requete r WHERE r.noteexav = :noteexav"),
    @NamedQuery(name = "Requete.findByNotefinaleav", query = "SELECT r FROM Requete r WHERE r.notefinaleav = :notefinaleav"),
    @NamedQuery(name = "Requete.findByNotecc", query = "SELECT r FROM Requete r WHERE r.notecc = :notecc"),
    @NamedQuery(name = "Requete.findByNotetp", query = "SELECT r FROM Requete r WHERE r.notetp = :notetp"),
    @NamedQuery(name = "Requete.findByNoteex", query = "SELECT r FROM Requete r WHERE r.noteex = :noteex"),
    @NamedQuery(name = "Requete.findByNotefinale", query = "SELECT r FROM Requete r WHERE r.notefinale = :notefinale")})
public class Requete implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idrequete")
    private Integer idrequete;
    @Basic(optional = false)
    @Column(name = "idEtudiant")
    private int idEtudiant;
    @Basic(optional = false)
    @Column(name = "idSession")
    private int idSession;
    @Basic(optional = false)
    @Column(name = "idoptionsemestre")
    private int idoptionsemestre;
    @Basic(optional = false)
    @Column(name = "idMatiere")
    private int idMatiere;
    @Column(name = "code")
    private String code;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "noteccav")
    private Float noteccav;
    @Column(name = "notetpav")
    private Float notetpav;
    @Column(name = "noteexav")
    private Float noteexav;
    @Column(name = "notefinaleav")
    private Float notefinaleav;
    @Column(name = "notecc")
    private Float notecc;
    @Column(name = "notetp")
    private Float notetp;
    @Column(name = "noteex")
    private Float noteex;
    @Column(name = "notefinale")
    private Float notefinale;
    @Lob
    @Column(name = "observation")
    private String observation;

    public Requete() {
    }

    public Requete(Integer idrequete) {
        this.idrequete = idrequete;
    }

    public Requete(Integer idrequete, int idEtudiant, int idSession, int idoptionsemestre, int idMatiere) {
        this.idrequete = idrequete;
        this.idEtudiant = idEtudiant;
        this.idSession = idSession;
        this.idoptionsemestre = idoptionsemestre;
        this.idMatiere = idMatiere;
    }

    public Integer getIdrequete() {
        return idrequete;
    }

    public void setIdrequete(Integer idrequete) {
        this.idrequete = idrequete;
    }

    public int getIdEtudiant() {
        return idEtudiant;
    }

    public void setIdEtudiant(int idEtudiant) {
        this.idEtudiant = idEtudiant;
    }

    public int getIdSession() {
        return idSession;
    }

    public void setIdSession(int idSession) {
        this.idSession = idSession;
    }

    public int getIdoptionsemestre() {
        return idoptionsemestre;
    }

    public void setIdoptionsemestre(int idoptionsemestre) {
        this.idoptionsemestre = idoptionsemestre;
    }

    public int getIdMatiere() {
        return idMatiere;
    }

    public void setIdMatiere(int idMatiere) {
        this.idMatiere = idMatiere;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Float getNoteccav() {
        return noteccav;
    }

    public void setNoteccav(Float noteccav) {
        this.noteccav = noteccav;
    }

    public Float getNotetpav() {
        return notetpav;
    }

    public void setNotetpav(Float notetpav) {
        this.notetpav = notetpav;
    }

    public Float getNoteexav() {
        return noteexav;
    }

    public void setNoteexav(Float noteexav) {
        this.noteexav = noteexav;
    }

    public Float getNotefinaleav() {
        return notefinaleav;
    }

    public void setNotefinaleav(Float notefinaleav) {
        this.notefinaleav = notefinaleav;
    }

    public Float getNotecc() {
        return notecc;
    }

    public void setNotecc(Float notecc) {
        this.notecc = notecc;
    }

    public Float getNotetp() {
        return notetp;
    }

    public void setNotetp(Float notetp) {
        this.notetp = notetp;
    }

    public Float getNoteex() {
        return noteex;
    }

    public void setNoteex(Float noteex) {
        this.noteex = noteex;
    }

    public Float getNotefinale() {
        return notefinale;
    }

    public void setNotefinale(Float notefinale) {
        this.notefinale = notefinale;
    }

    public String getObservation() {
        return observation;
    }

    public void setObservation(String observation) {
        this.observation = observation;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idrequete != null ? idrequete.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Requete)) {
            return false;
        }
        Requete other = (Requete) object;
        if ((this.idrequete == null && other.idrequete != null) || (this.idrequete != null && !this.idrequete.equals(other.idrequete))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Requete[ idrequete=" + idrequete + " ]";
    }
    
}
