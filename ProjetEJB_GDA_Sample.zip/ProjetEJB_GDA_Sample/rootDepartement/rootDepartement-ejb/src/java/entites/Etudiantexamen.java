/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entites;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Ernest
 */
@Entity
@Table(name = "etudiantexamen")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Etudiantexamen.findAll", query = "SELECT e FROM Etudiantexamen e"),
    @NamedQuery(name = "Etudiantexamen.findByIdetudiantexamen", query = "SELECT e FROM Etudiantexamen e WHERE e.idetudiantexamen = :idetudiantexamen"),
    @NamedQuery(name = "Etudiantexamen.findByIdEtudiant", query = "SELECT e FROM Etudiantexamen e WHERE e.idEtudiant = :idEtudiant"),
    @NamedQuery(name = "Etudiantexamen.findByIdMatiereProgrammee", query = "SELECT e FROM Etudiantexamen e WHERE e.idMatiereProgrammee = :idMatiereProgrammee")})
public class Etudiantexamen implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idetudiantexamen")
    private Integer idetudiantexamen;
    @Basic(optional = false)
    @Column(name = "idEtudiant")
    private int idEtudiant;
    @Basic(optional = false)
    @Column(name = "idMatiereProgrammee")
    private int idMatiereProgrammee;

    public Etudiantexamen() {
    }

    public Etudiantexamen(Integer idetudiantexamen) {
        this.idetudiantexamen = idetudiantexamen;
    }

    public Etudiantexamen(Integer idetudiantexamen, int idEtudiant, int idMatiereProgrammee) {
        this.idetudiantexamen = idetudiantexamen;
        this.idEtudiant = idEtudiant;
        this.idMatiereProgrammee = idMatiereProgrammee;
    }

    public Integer getIdetudiantexamen() {
        return idetudiantexamen;
    }

    public void setIdetudiantexamen(Integer idetudiantexamen) {
        this.idetudiantexamen = idetudiantexamen;
    }

    public int getIdEtudiant() {
        return idEtudiant;
    }

    public void setIdEtudiant(int idEtudiant) {
        this.idEtudiant = idEtudiant;
    }

    public int getIdMatiereProgrammee() {
        return idMatiereProgrammee;
    }

    public void setIdMatiereProgrammee(int idMatiereProgrammee) {
        this.idMatiereProgrammee = idMatiereProgrammee;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idetudiantexamen != null ? idetudiantexamen.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Etudiantexamen)) {
            return false;
        }
        Etudiantexamen other = (Etudiantexamen) object;
        if ((this.idetudiantexamen == null && other.idetudiantexamen != null) || (this.idetudiantexamen != null && !this.idetudiantexamen.equals(other.idetudiantexamen))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entites.Etudiantexamen[ idetudiantexamen=" + idetudiantexamen + " ]";
    }
    
}
