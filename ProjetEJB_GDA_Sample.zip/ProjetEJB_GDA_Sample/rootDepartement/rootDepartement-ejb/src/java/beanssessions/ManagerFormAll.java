/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beanssessions;

import entites.Annee;
import entites.Classe;
import entites.Cursus;
import entites.Departement;
import entites.Enseignant;
import entites.Enseigner;
import entites.Etudiant;
import entites.Evaluation;
import entites.Heure;
import entites.Inscription;
import entites.Matiere;
import entites.Minuite;
import entites.Noteevaluation;
import entites.Options;
import entites.Plagehoraire;
import entites.Salle;
import entites.Semestre;
import entites.Session;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author Thierrynems
 */
@Stateless(mappedName="formsBean")
public class ManagerFormAll implements ManagerFormAllLocal {
    @PersistenceContext(unitName = "rootDepartement-ejbPU")
    private EntityManager em;
    public final String baseMatricule="S";
    
    public void persist(Object object) {
        em.persist(object);
    }

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @Override  
   public boolean insertEtudiant(String nometud, String prenometud, Date datenaissetud, String lieuNaissance, String nationaliteetud, String sexeetud, String langue, String photoetud, String diplomeadmission, String cnietud,int idclasse,int idannee,int idoptions,int idcursus){
     
       Etudiant Etud=new Etudiant();
       Etud.setNometud(nometud);
       Etud.setPrenometud(prenometud);
       Etud.setDatenaissetud(datenaissetud);
       Etud.setLieuNaissance(lieuNaissance);
       Etud.setNationaliteetud(nationaliteetud);
       Etud.setLangue(langue);
       Etud.setSexeetud(sexeetud);
       Etud.setCnietud(cnietud);
       Etud.setDiplomeadmission(diplomeadmission);
       Etud.setPhotoetud(photoetud);
       Etud.setMatriculeetud(genereMatricule(idannee));
       Date dateinscription=null;
       Date CurrentDate=new Date();
       try{
                SimpleDateFormat formatter = new SimpleDateFormat("YYYY-MM-DD");
                String datecourante = formatter.format(CurrentDate); 
                dateinscription=formatter.parse(datecourante);
                Etud.setDateinscription(dateinscription);
            }catch(RuntimeException e) {
                
            }catch (ParseException ex) {
             Etud.setDateinscription(null);
        }
			
	  
       try{
           em.persist(Etud);
           //recuperation de l'id de l'etduiant inserée
          Query query=em.createNativeQuery("SELECT Max(idEtudiant) AS id FROM etudiant");
        //maxid from etudiant 
         int idEtudiant =(Integer)query.getSingleResult();
         InsertInscription(idclasse,idannee,idEtudiant,idoptions,idcursus,"",dateinscription,true);
           return true;
       }catch(Exception e){
           return false;
       }
       
       
   }
   
    public Boolean InsertInscription(int idoptionsemestre,int idannee,int idEtudiant,int idoptions,int idcursus,String codeinscriptionamin,Date dateincriptionadmin,boolean inscrit){
            Inscription Ins = new Inscription();
            Ins.setIdannee(idannee);
            Ins.setIdEtudiant(idEtudiant);
            Ins.setCodeinscriptionamin(codeinscriptionamin);
            Ins.setIdoptionsemestre(idoptionsemestre);
            Ins.setDateincriptionadmin(dateincriptionadmin);
            Ins.setDateincriptionadmin(dateincriptionadmin);
            Ins.setIdoptions(idoptions);
            Ins.setIdcursus(idcursus);
            Ins.setInscrit(inscrit);
            try{
                em.persist(Ins);
                return true;
            }catch(Exception e ){
                return false;
            }
         
    }
 //insertion et mise à jour de l'evaluation 
    @Override
    public Boolean saveEval(int idEtudiant,int idoptionsemestre,int idSession,int idMatiere,int idevaluation,int idoptions, String valeur,int type){
        /*
         * type determine s'il s'agit de la note de cc, note de d'examen ou l'anonymat
         * 0 CC
         * 1 Anonymat 
         * 2 Examidoptionsemestre
         */
        if(type==0){
            Float notecc=Float.parseFloat(valeur);
            Noteevaluation Note =this.findNoteEval(idEtudiant, idoptionsemestre, idSession, idMatiere, idevaluation, idoptions);
            try{
                
                //il existe deja une evaluation
                Boolean Isexam=false;
                Float noteex=new Float(0);
                int idtypeevaluationcc=1;
                int idtypeevaluationex=2;
                int poidcc=0;
                int poidex=0;
                
                 Collection<Evaluation> evalex=this.SelectEval(idoptionsemestre, idMatiere, idSession,idtypeevaluationex);
                for(Evaluation eval: evalex){
                     poidex=eval.getPoidseval();
                     Isexam=true;
                     break;
                }
                //
                 Collection<Evaluation> evalcc=this.SelectEval(idoptionsemestre, idMatiere, idSession,idtypeevaluationcc);
                for(Evaluation eval: evalcc){
                     poidcc=eval.getPoidseval();
                    break;
                }
                
                if(Isexam){
                    //examen existe 
                    //recherche de l'evaluation SelectEval(int idoptionsemestre,int idMatiere, int idSession, int idtypeevaluation)
                    float notefinale=0;
                   try{
                        noteex=Note.getNoteex();
                        notefinale=((noteex*poidex)+(notecc*poidcc))/(poidcc+poidex);
                        
                   }catch(NullPointerException err){
                        noteex=new Float(0);
                        notefinale=((noteex*poidex)+(notecc*poidcc))/(poidcc+poidex);
                   }
                    Note.setNotefinale(notefinale);
                    Note.setNotecc(notecc);
                    Note.setNoteex(noteex);
                    em.merge(Note);
                    return true;
              }else{
                    float notefinale=(notecc*poidcc)/poidcc;
                    Note.setNotefinale(notefinale);
                    Note.setNotecc(notecc);
                    em.merge(Note);
                    return true;
                }
 
          }catch(NullPointerException e){
              //insertion de la note
                int poidcc=0;
                float notefinale=0;
                int idtypeevaluationcc=1;
                Collection<Evaluation> evalcc=this.SelectEval(idoptionsemestre, idMatiere, idSession,idtypeevaluationcc);
                for(Evaluation eval: evalcc){
                     poidcc=eval.getPoidseval();
                    break;
                }
                notefinale=(notecc*poidcc)/poidcc;
                Noteevaluation noteEval=new Noteevaluation();
                noteEval.setIdEtudiant(idEtudiant);
                noteEval.setIdoptionsemestre(idoptionsemestre);
                noteEval.setIdSession(idSession);
                noteEval.setIdMatiere(idMatiere);
                noteEval.setIdevaluation(idevaluation);
                noteEval.setIdoptions(idoptions);
                noteEval.setNotecc(notecc);
                noteEval.setNotefinale(notefinale);
                em.persist(noteEval);
                return true;
          }
        }else if(type==1){//ano
            String anonymat=valeur;
            Noteevaluation Note =this.findNoteEval(idEtudiant, idoptionsemestre, idSession, idMatiere, idevaluation, idoptions);
           // System.out.println(idevaluation);
            try{
                
                Note.setAnonymat(anonymat);
                em.merge(Note);
                return true;
 
          }catch(Exception e){
                Noteevaluation noteEval=new Noteevaluation();
                noteEval.setIdEtudiant(idEtudiant);
                noteEval.setIdoptionsemestre(idoptionsemestre);
                noteEval.setIdSession(idSession);
                noteEval.setIdMatiere(idMatiere);
                noteEval.setIdevaluation(idevaluation);
                noteEval.setIdoptions(idoptions);
                noteEval.setAnonymat(anonymat);
                em.persist(noteEval);
                return true;
          } 
        }else if(type==2){
            Float noteExam=Float.parseFloat(valeur);
            Noteevaluation Note =this.findNoteEval(idEtudiant, idoptionsemestre, idSession, idMatiere, idevaluation, idoptions);
            try{
                
                //il existe deja une evaluation
                Boolean Iscc=false;
                Float notecc=new Float(0);
                int idtypeevaluationcc=1;
                int idtypeevaluationex=2;
                int poidcc=0;
                int poidex=0;
                
                 Collection<Evaluation> evalcc=this.SelectEval(idoptionsemestre, idMatiere, idSession,idtypeevaluationcc);
                for(Evaluation eval: evalcc){
                     poidcc=eval.getPoidseval();
                     Iscc=true;
                     break;
                }
                //
                 Collection<Evaluation> evalex=this.SelectEval(idoptionsemestre, idMatiere, idSession,idtypeevaluationex);
                for(Evaluation eval: evalex){
                     poidex=eval.getPoidseval();
                    break;
                }
                
                if(Iscc){
                    //cc existe 
                    //recherche de l'evaluation SelectEval(int idoptionsemestre,int idMatiere, int idSession, int idtypeevaluation)
                    float notefinale=0;
                   try{
                        notecc=Note.getNotecc();
                        notefinale=((noteExam*poidex)+(notecc*poidcc))/(poidcc+poidex);
                        
                   }catch(NullPointerException err){
                        notecc=new Float(0);
                        notefinale=((noteExam*poidex)+(notecc*poidcc))/(poidcc+poidex);
                   }
                    Note.setNotefinale(notefinale);
                    Note.setNotecc(notecc);
                    Note.setNoteex(noteExam);
                    em.merge(Note);
                    return true;
              }else{
                    float notefinale=(noteExam*poidex)/poidex;
                    Note.setNotefinale(notefinale);
                    Note.setNotecc(noteExam);
                    em.merge(Note);
                    return true;
                }
 
          }catch(NullPointerException e){
              //insertion de la note
                return false;
          }
        }else{
            return false;
        }
    }
    
    @Override
  public  Noteevaluation findNoteEval(int idEtudiant,int idoptionsemestre,int idSession,int idMatiere,int idevaluation,int idoptions){
      
      try{
          Query query =em.createNamedQuery("Noteevaluation.findnote");
          query.setParameter("idEtudiant", idEtudiant);
          query.setParameter("idoptionsemestre", idoptionsemestre);
          query.setParameter("idSession", idSession);
          query.setParameter("idoptions", idoptions);
          query.setParameter("idMatiere", idMatiere);
          return (Noteevaluation)query.getSingleResult();
      }catch(NoResultException err){
          return null;
      }catch(NullPointerException e){
          return null;
      }catch(NonUniqueResultException exc){
          Query query =em.createNamedQuery("Noteevaluation.findnote");
          query.setParameter("idEtudiant", idEtudiant);
          query.setParameter("idoptionsemestre", idoptionsemestre);
          query.setParameter("idSession", idSession);
          query.setParameter("idoptions", idoptions);
          query.setParameter("idMatiere", idMatiere);
          Collection<Noteevaluation> eval=query.getResultList();
          Noteevaluation noteEval= new Noteevaluation();
          for(Noteevaluation note: eval){
               noteEval=note;
              break;
          }
          return noteEval;
      }
  }
    //recherche des anononymats d'une evaluation 
    @Override   
    public Collection<Noteevaluation> findAnonymatEval(int idoptionsemestre, int idSession, int idMatiere,int idoptions){
        String sql="SELECT * FROM noteevaluation WHERE idoptionsemestre='"+idoptionsemestre+"' AND idSession='"+idSession+"' AND idMatiere='"+idMatiere+"' AND idoptions='"+idoptions+"' AND (anonymat!='' OR anonymat IS NOT NULL)";
       // System.out.println(sql);
        try{
        Query query=em.createNativeQuery(sql, Noteevaluation.class);
        return query.getResultList();
        }catch(NoResultException err){
            return null;
        }catch(NullPointerException ex){
            return null;
        }
        
    }
   //verification de l'anonymat 
    @Override
 public  Boolean findAnoEval(int idsemestre,int idMatiere,int idoptions,int idSession,String anonymat){
      try{
          Query query =em.createNamedQuery("Noteevaluation.findByAnonymatAndEvaluation");  
          query.setParameter("idoptionsemestre", idsemestre);
          query.setParameter("anonymat", anonymat);
          query.setParameter("idMatiere", idMatiere);
          query.setParameter("idoptions", idoptions);
          query.setParameter("idSession", idSession);
          //n.anonymat = : AND n.idoptionsemestre = :idoptionsemestre AND n.idMatiere = :idMatiere  AND n. = :idoptions AND n.idSession = :idSession
          Collection<Noteevaluation> noteEval=query.getResultList();
          if(noteEval.size()>0) return true;
          else return false;
      }catch(NoResultException err){
          return false;
      }catch(NullPointerException e){
          return false;
      }catch(Exception exc){
          return false;
      }
  }   
    @Override
  public Boolean InsertEval(Evaluation e){
      try{
                em.persist(e);
                return true;
            }catch(Exception er ){
                return false;
            } 
  }
  //insertion session 
    @Override
    public Boolean InsertSession(Session ses){ 
        try{
                em.persist(ses);
                return true; 
            }catch(Exception e ){
                return false;
            }
    }
    //function de selection de l'année académique 
    @Override
    public Collection<Annee> SelectAnnee(){
      //  System.out.println("selection des année academiques");
         Query query =em.createNamedQuery("Annee.findAll");
         return query.getResultList();
    }
    
    @Override
    public Collection<Cursus> SelectCursus(){
        Query query =em.createNamedQuery("Cursus.findAll");
         return query.getResultList();
    }
    
    @Override
    public Collection<Options> SelectOption(){
        Query query =em.createNamedQuery("Options.findAll");
        return query.getResultList();
    }
    
    @Override
    public Collection<Classe> SelectClasse(){
           Query query =em.createNamedQuery("Classe.findAll");
          return query.getResultList();
    }
      
    @Override
   public Collection<Etudiant> SelectListeEtudiant(){
          Query query =em.createNamedQuery("Etudiant.findAll");
          return query.getResultList();
   } 
 //return liste session    
    @Override
  public Collection<Session> SelectListeSession(){
          Query query =em.createNamedQuery("Session.findAll");
          return query.getResultList();
   }  
  //selection des session connaisant l'année académique 
    @Override
    public Collection<Session> SelectSessionByAnnee(int idannee){
          Query query =em.createNamedQuery("Session.findByIdannee");
          query.setParameter("idannee",idannee);
          return query.getResultList();
   }
 //selection des departement academique 
    @Override
    public Collection<Departement> SelectDepartement(){
          Query query =em.createNamedQuery("Departement.findAll");
          return query.getResultList();
   }
//selection des semestre LMD 
    @Override
    public Collection<Semestre> SelectSemestre(){
          Query query =em.createNamedQuery("Semestre.findAll");
          return query.getResultList();
   }
    @Override
 public Collection<Evaluation> SelectEval(int idoptionsemestre,int idMatiere, int idSession, int idtypeevaluation){
          try{
          Query query =em.createNamedQuery("Evaluation.findBySessionSemestre");
          //e.idoptionsemestre = :idoptionsemestre AND e.idMatiere = :idMatiere AND e.idSession = :idSession AND e.idtypeevaluation = :idtypeevaluation
          query.setParameter("idoptionsemestre", idoptionsemestre);
          query.setParameter("idMatiere", idMatiere);
          query.setParameter("idSession", idSession);
          query.setParameter("idtypeevaluation", idtypeevaluation);
          return query.getResultList();
         }catch(NoResultException e){
              return null;
         }catch(NullPointerException e){
              return null;
         }
   }   
  //selection desetudiants inscrits 
    @Override
    public Collection<Etudiant> SelectEtudInscrit(int idclasse,int idannee,int idoptions){
        String sql="SELECT DISTINCT E.* FROM Etudiant E JOIN inscription I ON I.idetudiant=E.idetudiant WHERE idoptionsemestre='"+idclasse+"' AND idannee='"+idannee+"' AND idoptions='"+idoptions+"' ORDER BY E.nometud,prenometud";
        try{
        Query query=em.createNativeQuery(sql,Etudiant.class);
        return query.getResultList();
        }catch(NoResultException err){
            return null;
        }
    }
  //selection de la classe connaisant l'id du semestre 
    @Override
    public Classe SelectClasseByidSemestre(int idsemestre){
         String sql="SELECT C.* FROM classe C JOIN semestre S ON C.code=S.classe WHERE S.idsemestre='"+idsemestre+"'";
         try{
             Query query=em.createNativeQuery(sql, Classe.class);
             return (Classe)query.getSingleResult();
         }catch(NoResultException err){
              return null;
         }
    }
 //selection des matiere programmee 
    @Override
    public List<Matiere>  SelectMatiereProg(int idoptionsemestre,int idsession){
        
        String sql="SELECT DISTINCT m.idmatiere,m.codematiere,m.libelle_fr,m.libelle_en FROM matiere m JOIN matiereprogrammee mp ON mp.idmatiere=m.idmatiere  WHERE mp.idoptionsemestre ='"+idoptionsemestre+"' AND mp.idsession ='"+idsession+"'";
        System.out.println(sql);
        try{            
        Query query =em.createNativeQuery(sql,Matiere.class);
        //        createNativeQuery();
        
          return query.getResultList();
        }catch(NoResultException e ){
            System.out.println("Exception");
            return null;  
        }  
    }
    
  //select option by idcursus 
    @Override
   public Collection<Options> SelectOptionsByCursus(int idcursus){
          Query query =em.createNamedQuery("Options.findByIdCursus");
          query.setParameter("idCursus",idcursus);
          return query.getResultList();
   } 
   //function genere matricule 
    public String genereMatricule(int idannee){
        //selection du max id dans la table etudiant 
        Integer maxId= new Integer(0);
        Query query; 
        try{
         query=em.createNativeQuery("SELECT Max(idEtudiant) AS id FROM etudiant");
        //maxid from etudiant 
         maxId=(Integer)query.getSingleResult();
         maxId++;
        }catch(NoResultException e){
         maxId=new Integer(0);; 
         maxId++;
        }catch(NullPointerException ex){
           maxId=new Integer(0); 
           maxId++; 
        }
        
        String numSerie="";
        if(maxId<10){
            numSerie="000"+maxId;
        }else if(maxId>10 && maxId<100){
           numSerie="00"+maxId;
       }else if(maxId>100 && maxId<1000){
           numSerie="0"+maxId;
       }else{
            numSerie=""+maxId;
       }
        //recuperation de l'année en cours 
        query=em.createNamedQuery("Annee.findByIdannee");
        query.setParameter("idannee",idannee);
        Annee objannee=(Annee)query.getSingleResult();
        String codeannee=objannee.getCode();
        String matricule=codeannee+""+baseMatricule+ ""+numSerie;
        return matricule;
    }
    
    //selection de matière programme 
    @Override
    public Collection<Matiere> getMatiereProgAdopte(int idannee, int idoptions, int idsemestre){
        String sql="SELECT DISTINCT M.* FROM Matiere M JOIN matiereue mu ON M.idmatiere =mu.idmatiere JOIN ue U ON U.idue=mu.idue JOIN ueprogramme up ON up.idue=U.idue JOIN programme p ON p.idprogramme=up.idprogramme JOIN programmeadopte pd ON pd.idProgramme=p.idProgramme WHERE pd.idsemestre='"+idsemestre+"' AND pd.idoptions='"+idoptions+"' AND idannee='"+idannee+"'";
        try{
        Query query=em.createNativeQuery(sql, Matiere.class);
        return query.getResultList();
        }catch(NoResultException ex){
            return null;
        }catch(Exception ex){
            return null;
        }
    }
   ///selection de la liste des enseignants 
    @Override
    public Collection<Enseignant> getListEnseignant(){
        try{
            Query query=em.createNamedQuery("Enseignant.findAll");
            return query.getResultList();
        }catch(NoResultException ex){
            return  null;
        }catch(Exception e){
             return null;
        }
    }
   //liste des plages horaire
    @Override
    public Collection<Plagehoraire> getListHoraire(){
        try{
            Query query=em.createNamedQuery("Plagehoraire.findAll");
            return query.getResultList();
        }catch(NoResultException ex){
            return  null;
        }catch(Exception e){
             return null;
        }
    }
  //liste des salles de classe 
    @Override
   public Collection<Salle> getListSalle(){
        try{
            Query query=em.createNamedQuery("Salle.findAll");
            return query.getResultList();
        }catch(NoResultException ex){
            return  null;
        }catch(Exception e){
             return null;
        }
    } 
 //verification de l'existance d'une plage Horaire lors de l'enregistre s
    @Override
    public boolean IsExisteHoraire(int idhoraire,String datej){
        String sql="SELECT * FROM enseigner WHERE idplagehoraire='"+idhoraire+"' AND `date`='"+datej+"'";
        System.out.println(sql);
        try{
            Query query=em.createNativeQuery(sql, Enseigner.class);
            Collection<Enseigner> result= query.getResultList();
            if(result.size()>0) return true;
            else return false;
        }catch(NoResultException ex){
            return  false;
        }catch(Exception e){
             return false;
        }
    }
   //function d'enregistrement des enseignments 
    @Override
    public void saveEntitie(Object o){
        em.persist(o);
    }
  //retourne du libelle de l'heure connaissant l'id
    @Override
    public Heure getHeureById(int idheure){
          try{
            Query query=em.createNamedQuery("Heure.findByIdheure");
            query.setParameter("idheure", idheure);
            return (Heure)query.getSingleResult();
        }catch(NoResultException ex){
            return  null;
        }catch(Exception e){
             return null;
        }
    }
    //Minuite
    @Override
 public Minuite getMinuiteById(int idminuite){
          try{
            Query query=em.createNamedQuery("Minuite.findByIdminuite");
            query.setParameter("idminuite", idminuite);
            return (Minuite)query.getSingleResult();
        }catch(NoResultException ex){
            return  null;
        }catch(Exception e){
             return null;
        }
    } 
  //get date enseigne
    @Override
    public Collection<Enseigner> getDateEnseigne(int idsession,int idsemestre){
        try{
            Query query=em.createNativeQuery("SELECT * FROM enseigner WHERE idoptionsemestre='"+idsemestre+"' AND idsession='"+idsession+"' GROUP BY date",Enseigner.class);
            return query.getResultList();
        }catch(NoResultException ex){
            return  null;
        }catch(Exception e){
             return null;
        }
    }
  //get enseignement d'une période 
    
    @Override
    public Collection<Enseigner> getEnseigne(int idsession,int idsemestre,String datedebut,String datefin){
        try{
            Query query=em.createNativeQuery("SELECT E.* FROM enseigner E JOIN plagehoraire pg ON E.idplagehoraire=pg.idplagehoraire JOIN heure H ON H.idheure=pg.idheure JOIN Minuite M ON M.idminuite=pg.idminuite WHERE idoptionsemestre='"+idsemestre+"' AND idsession='"+idsession+"' AND (E.`date` BETWEEN '"+datedebut+"' AND '"+datefin+"') GROUP BY idplagehoraire  ORDER BY idplagehoraire,H.libelle_fr ASC  ",Enseigner.class);
            return query.getResultList();
        }catch(NoResultException ex){
            return  null;
        }catch(Exception e){
             return null;
        }
    }
  //get plage horaire by id 
    @Override
    public Plagehoraire getPlageHoraireById(int idplage){
      try{
            Query query=em.createNamedQuery("Plagehoraire.findByIdplagehoraire");
            query.setParameter("idplagehoraire", idplage);
            return (Plagehoraire) query.getSingleResult();
        }catch(NoResultException ex){
            return  null;
        }catch(Exception e){
             return null;
        }  
    }
  ///get enseignant by id   
    @Override
  public Enseignant getEnseignantById(int idenseignant){
      try{
            Query query=em.createNamedQuery("Enseignant.findByIdEnseignant");
            query.setParameter("idEnseignant", idenseignant);
            return (Enseignant) query.getSingleResult();
        }catch(NoResultException ex){
            return  null;
        }catch(Exception e){
             return null;
        }  
  }
//get Matiere by id 
    @Override
   public Matiere getMatiereById(int idmatiere){
      try{
            Query query=em.createNamedQuery("Matiere.findByIdMatiere");
            query.setParameter("idMatiere", idmatiere);
            return (Matiere) query.getSingleResult();
        }catch(NoResultException ex){
            return  null;
        }catch(Exception e){
             return null;
        }  
  }
  //get Salle by id
    @Override
   public Salle getSalleById(int idsalle){
      try{
            Query query=em.createNamedQuery("Salle.findByIdsalle");
            query.setParameter("idsalle", idsalle);
            return (Salle) query.getSingleResult();
        }catch(NoResultException ex){
            return  null;
        }catch(Exception e){
             return null;
        }  
  }
   //get enseigne par semestre session
    @Override  
    public Enseigner getEnseigneAll(int idplage,String date){
        try{
            Query query=em.createNativeQuery("SELECT E.* FROM enseigner E WHERE idplagehoraire='"+idplage+"' AND date='"+date+"' LIMIT 1",Enseigner.class);
            return (Enseigner)query.getSingleResult();
        }catch(NoResultException ex){
            return  null;
        }catch(Exception e){
             return null;
        }
    }
}
