/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beanssessions;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author Ernest
 */
@Stateless(mappedName="formBean")
public class gestionaireForm implements gestionaireFormLocal {
    @PersistenceContext(unitName = "rootDepartement-ejbPU")
    private EntityManager ema;
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    @Override
    public void save(Object e)
    {
     ema.persist(e);
    }
}
