/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import beanssessions.ManagerFormAllLocal;
import entites.Annee;
import entites.Classe;
import entites.Cursus;
import entites.Departement;
import entites.Enseignant;
import entites.Enseigner;
import entites.Etudiant;
import entites.Evaluation;
import entites.Heure;
import entites.Matiere;
import entites.Minuite;
import entites.Noteevaluation;
import entites.Options;
import entites.Plagehoraire;
import entites.Salle;
import entites.Semestre;
import entites.Session;
import java.beans.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.persistence.EntityManager;
import javax.transaction.UserTransaction;

/**
 *
 * @author Thierrynems
 */
public class ManagerBeans implements Serializable {
    
    public static final String PROP_SAMPLE_PROPERTY = "sampleProperty";
    private String sampleProperty;
    private PropertyChangeSupport propertySupport;
   // ManagerFormAllLocal objRemote;
//    private Collection<Annee> listeanne;
    public ManagerBeans() {
        propertySupport = new PropertyChangeSupport(this);
        /*try {
            
            Context context = new InitialContext();
           ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }
        * 
        */
    }
    
    public String getSampleProperty() {
        return sampleProperty;
    }
    
    public void setSampleProperty(String value) {
        String oldValue = sampleProperty;
        sampleProperty = value;
        propertySupport.firePropertyChange(PROP_SAMPLE_PROPERTY, oldValue, sampleProperty);
    }
    
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.addPropertyChangeListener(listener);
    }
    
    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.removePropertyChangeListener(listener);
    }
    
     //function de selection de l'année académique 
    
    public Collection<Annee> getAnnee(){
      //  System.out.println("selection des année academiques");
        try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection listAnnee=objRemote.SelectAnnee();
            return listAnnee;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }
         
    }
   //get liste cursus 
    public Collection<Cursus> getCursus(){
        try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection listeCursus=objRemote.SelectCursus();
            return listeCursus;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }
        
    }
    
   public Collection<Options> getOption(){
       try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection listeOption=objRemote.SelectOption();
            
            return listeOption;
         //   return null;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }
       
   }
 public Collection <Classe> getClasse(){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection listeClasse=objRemote.SelectClasse();
            return listeClasse;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }
        
 }  

 public Collection<Etudiant> getListEtudiant(){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection listeEtud=objRemote.SelectListeEtudiant();
            return listeEtud;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
 
 //return liste session 
 public Collection<Session> getListSession(){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection listSession=objRemote.SelectListeSession();
            return listSession;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
  //return liste session 
 public Collection<Session> getSessionByAnnee(int idannee){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection listSession=objRemote.SelectSessionByAnnee(idannee);
            return listSession;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
 //get options by cursus 
  public Collection<Options> getOptionsByCursus(int idcursus){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection listOption=objRemote.SelectOptionsByCursus(idcursus);
            return listOption;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
  //return liste Departement 
 public Collection<Departement> getListDepartement(){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection listDepartement=objRemote.SelectDepartement();
            return listDepartement;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
 
   //return liste Departement 
 public Collection<Semestre> getListSemestre(){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection listSemestre=objRemote.SelectSemestre();
            return listSemestre;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
 //obtenir la liste des matières programmées 
 public List<Matiere> getMatiereProg(int idoptionsemestre, int idsession){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            List<Matiere> matiereProg=objRemote.SelectMatiereProg(idoptionsemestre, idsession);
            return matiereProg;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
 //obtenir les annonymats d'une evaluation
 public Collection<Noteevaluation> findAnonymatEval(int idoptionsemestre, int idSession, int idMatiere,int idoptions){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection<Noteevaluation> noteEval=objRemote.findAnonymatEval(idoptionsemestre, idSession, idMatiere, idoptions);
            return noteEval;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }   
 }
 //verification de l'anonymat
 public Boolean IsExistAnoEval(int idsemestre,int  idMatiere,int idoptions,int idSession,String anonymat){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            //findAnoEval(int idsemestre,int idMatiere,int idoptions,int idSession,String anonymat)
            Boolean trouve=objRemote.findAnoEval(idsemestre,idMatiere,idoptions,idSession,anonymat);
            return trouve;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
 
 //selection de l'eval 
 public Collection<Evaluation> getEvaluation(int idoptionsemestre,int idMatiere, int idSession, int idtypeevaluation){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection Eval=objRemote.SelectEval(idoptionsemestre, idMatiere, idSession, idtypeevaluation);
            return Eval;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
 
 //obtenir la liste des etudiant de la classe 
 public Collection<Etudiant> getListEtudInscrit(int idclasse,int idannee,int idoptions){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection listEtud=objRemote.SelectEtudInscrit(idclasse, idannee, idoptions);
            return listEtud;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
//Obtenir la classe connaissant l'id du semestre 
 public Classe getClasseByidSemestre(int idsemestre){
       try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Classe cl=objRemote.SelectClasseByidSemestre(idsemestre);
            return cl;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
 //function de retour de la note d'evalution d'un etudiant 
 public Noteevaluation getNoteEtud(int idEtudiant,int idoptionsemestre,int idSession,int idMatiere,int idevaluation,int idoptions){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Noteevaluation eval =objRemote.findNoteEval(idEtudiant, idoptionsemestre, idSession, idMatiere, idevaluation, idoptions);
            return eval;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
 public Boolean CreateEval(Evaluation eval){
    try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            if(objRemote.InsertEval(eval)) return true;
            else return false;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e); 
        }      
 }
 //enregistre d'une evalaution 
 public Boolean saveEval(int idEtudiant,int idoptionsemestre,int idSession,int idMatiere,int idevaluation,int idoptions, String valeur,int type){
    try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            if(objRemote.saveEval(idEtudiant, idoptionsemestre, idSession, idMatiere, idevaluation, idoptions, valeur, type)) return true;
            else return false;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e); 
        }         
 }
 
    public void persist(Object object) {
        /* Add this to the deployment descriptor of this module (e.g. web.xml, ejb-jar.xml):
         * <persistence-context-ref>
         * <persistence-context-ref-name>persistence/LogicalName</persistence-context-ref-name>
         * <persistence-unit-name>rootDepartement-ejbPU</persistence-unit-name>
         * </persistence-context-ref>
         * <resource-ref>
         * <res-ref-name>UserTransaction</res-ref-name>
         * <res-type>javax.transaction.UserTransaction</res-type>
         * <res-auth>Container</res-auth>
         * </resource-ref> */
        try {
            Context ctx = new InitialContext();
            UserTransaction utx = (UserTransaction) ctx.lookup("java:comp/env/UserTransaction");
            utx.begin();
            EntityManager em = (EntityManager) ctx.lookup("java:comp/env/persistence/LogicalName");
            em.persist(object);
            utx.commit();
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }
    }
    
 ///function de retour de la matière programmées
 public Collection<Matiere> getMatiereProgAdopte(int idannee,int idoptions,int idsemestre){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection<Matiere> MatProg =objRemote.getMatiereProgAdopte(idannee, idoptions, idsemestre);
            return MatProg;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
 
 //liste des enseignants 
 public Collection<Enseignant> getListEnseigant(){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection<Enseignant> ens =objRemote.getListEnseignant();
            return ens;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
 //liste des plage horaires
 public Collection<Plagehoraire> getListHoraire(){
     try {
            Context context = new InitialContext();
            ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
            Collection<Plagehoraire> horaire =objRemote.getListHoraire();
            return horaire;
           
        } catch (Exception e) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
            throw new RuntimeException(e);
        }  
 }
 
 //liste des salles 
    public Collection<Salle> getListSalle(){
        try {
               Context context = new InitialContext();
               ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
               Collection<Salle> salle =objRemote.getListSalle();
               return salle;

           } catch (Exception e) {
               Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
               throw new RuntimeException(e);
           }  
    }
  //verifi horaire enseigne
    public boolean IsExisteHoraire(int horaire,String date){
        try {
               Context context = new InitialContext();
               ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
               return objRemote.IsExisteHoraire(horaire, date);

           } catch (Exception e) {
               Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
               throw new RuntimeException(e);
           }  
    }
    //enregistrement d'object
    public void save(Object o){
        try {
               Context context = new InitialContext();
               ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
               objRemote.saveEntitie(o);
           } catch (Exception e) {
               Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
               throw new RuntimeException(e);
           }  
    }
   //get heure 
    public Heure getHeureById(int idheure){
          try {
               Context context = new InitialContext();
               ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
               return objRemote.getHeureById(idheure);
           } catch (Exception e) {
               Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
               throw new RuntimeException(e);
           }  
    }
  //get Miniute
  public Minuite getMinuiteById(int idminuite){
          try {
               Context context = new InitialContext();
               ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
               return objRemote.getMinuiteById(idminuite);
           } catch (Exception e) {
               Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
               throw new RuntimeException(e);
           }  
    }  
  //get date enseigne
  public Collection<Enseigner> getDateEnseigne(int idsemestre,int idsession){
          try {
               Context context = new InitialContext();
               ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
               return objRemote.getDateEnseigne(idsession, idsemestre);
           } catch (Exception e) {
               Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
               throw new RuntimeException(e);
           }  
    }  
 //get Enseignement 
  public Collection<Enseigner> getEnseigne(int idsemestre,int idsession,String datedebut,String datefin){
          try {
               Context context = new InitialContext();
               ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
               return objRemote.getEnseigne(idsession, idsemestre,datedebut,datefin);
           } catch (Exception e) {
               Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
               throw new RuntimeException(e);
           }  
    } 
  //get enseignen all
  public Enseigner getEnseigneAll(int idplage,String date){
          try {
               Context context = new InitialContext();
               ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
               return objRemote.getEnseigneAll(idplage,date);
           } catch (Exception e) {
               Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
               throw new RuntimeException(e);
           }  
    }  
  //get plage hoaraire
  public Plagehoraire getPlageById(int idplage){
          try {
               Context context = new InitialContext();
               ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
               return objRemote.getPlageHoraireById(idplage);
           } catch (Exception e) {
               Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
               throw new RuntimeException(e);
           }  
    }  
  //get Enseigant by id
  public Enseignant getEnseigantId(int idenseignant){
          try {
               Context context = new InitialContext();
               ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
               return objRemote.getEnseignantById(idenseignant);
           } catch (Exception e) {
               Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
               throw new RuntimeException(e);
           }  
    }  
  //get Matiere by id
  public Matiere getMatiereId(int idmatiere){
          try {
               Context context = new InitialContext();
               ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
               return objRemote.getMatiereById(idmatiere);
           } catch (Exception e) {
               Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
               throw new RuntimeException(e);
           }  
    }  
//get classe by id 
   public Salle getSalleId(int idsalle){
          try {
               Context context = new InitialContext();
               ManagerFormAllLocal objRemote=(ManagerFormAllLocal)context.lookup("formsBean");
               return objRemote.getSalleById(idsalle);
           } catch (Exception e) {
               Logger.getLogger(getClass().getName()).log(Level.SEVERE, "exception caught", e);
               throw new RuntimeException(e);
           }  
    }  
  
}
