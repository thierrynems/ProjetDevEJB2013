/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package managerServlets;

import beanssessions.gestionaireFormLocal;
import entites.Enseignant;
import entites.Matiereprogrammee;
import entites.Plagehoraire;
import entites.Programmeadopte;
import entites.Ressources;
import entites.Salle;
import entites.Surveillant;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Ernest
 */
@WebServlet(name = "manageForm", urlPatterns = {"/manageForm"})
public class manageForm extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet manageForm</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet manageForm at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        /*
         * Gestion du formulaire des enseignants----
         */
        if ("formEnseignant".equals(request.getParameter("formulaire"))) {
            try {
                //processRequest(request, response);
                String civiliteEnseignant = request.getParameter("civiliteEnseignant");
                String nomEnseignant = request.getParameter("nomEnseignant");
                String prenomEnseignant = request.getParameter("prenomEnseignant");
                String dateNaissEnseignant = request.getParameter("dateNaissEnseignant");

                SimpleDateFormat sdf = new SimpleDateFormat("yy/MM/dd");
                Date d = sdf.parse(dateNaissEnseignant);

                String lieuNaissEnseignant = request.getParameter("lieuNaissEnseignant");
                String sexeEnseignant = request.getParameter("sexeEnseignant");
                String photoEnseignant = request.getParameter("photoEnseignant");
                String deptEnseignant = request.getParameter("deptEnseignant");
                String categorieEnseignant = request.getParameter("categorieEnseignant");
                String specialiteEnseignant = request.getParameter("specialiteEnseignant");
                String codeEnseignant = request.getParameter("codeEnseignant");
                String matriculeEnseignant = request.getParameter("matriculeEnseignant");
                String titreEnseignant = request.getParameter("titreEnseignant");
                String gradeEnseignant = request.getParameter("gradeEnseignant");
                try {
                    Context context = new InitialContext();
                    gestionaireFormLocal con = (gestionaireFormLocal) context.lookup("formBean");

                    Enseignant ens = new Enseignant();
                    ens.setCategorieenseig(categorieEnseignant);
                    ens.setCivilite(civiliteEnseignant);
                    ens.setCodeenseignant(codeEnseignant);
                    ens.setDatenaiss(d);
                    ens.setGrade(gradeEnseignant);
                    ens.setIddepartement(Integer.parseInt(deptEnseignant));
                    ens.setIdusers(1);
                    ens.setLieunaiss(lieuNaissEnseignant);
                    ens.setMatriculeeng(matriculeEnseignant);
                    ens.setNomenseig(nomEnseignant);
                    ens.setPhoto(photoEnseignant);
                    ens.setPrenomenseig(prenomEnseignant);
                    ens.setSexe(sexeEnseignant);
                    ens.setSpecialite(specialiteEnseignant);
                    ens.setTitre(titreEnseignant);

                    con.save(ens);
                    RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=SaisieEnseignant.jsp");
                    dp.forward(request, response);
                } catch (NamingException e) {
                    e.printStackTrace();
                } catch (NullPointerException e) {
                    RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=SaisieEnseignant.jsp");
                    dp.forward(request, response);
                }

            } catch (ParseException ex) {
                Logger.getLogger(manageForm.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else if ("formSalle".equals(request.getParameter("formulaire"))) {
            String codesalle = request.getParameter("codesalle");
            String libelle_fr = request.getParameter("libelle_fr");
            String libelle_en = request.getParameter("libelle_en");
            String capacite = request.getParameter("capacite");
            String description = request.getParameter("description");
            try {
                Context context = new InitialContext();
                gestionaireFormLocal con = (gestionaireFormLocal) context.lookup("formBean");

                Salle sal = new Salle();
                sal.setCapacite(Integer.parseInt(capacite));
                sal.setCodesalle(codesalle);
                sal.setDescription(description);
                sal.setLibelleEn(libelle_en);
                sal.setLibelleFr(libelle_fr);
                con.save(sal);
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=Salle.jsp");
                dp.forward(request, response);
            } catch (NamingException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=Salle.jsp");
                dp.forward(request, response);
            }
        } else if ("formPlage".equals(request.getParameter("formulaire"))) {
            String heureDebut = request.getParameter("heureDebut");
            String minuteDebut = request.getParameter("minuteDebut");
            String heureFin = request.getParameter("heureFin");
            String minuteFin = request.getParameter("minuteFin");
            String dateplage = request.getParameter("dateplage");
            String codeplage = request.getParameter("codeplage");

            System.out.println("la date est=" + dateplage);
            try {
                Context context = new InitialContext();
                gestionaireFormLocal con = (gestionaireFormLocal) context.lookup("formBean");

                Plagehoraire pl = new Plagehoraire();
                //---Traitement de la date------------- 
                Date dpl = null;
                try {
                    SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
                    dpl = sdf1.parse(dateplage);
                } catch (RuntimeException e) {
                } catch (ParseException ex) {
                    Logger.getLogger(FormServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
                //---fin du traitement de la date-------
                pl.setDate(dpl);
                pl.setCode(codeplage);
                pl.setIdheure(Integer.parseInt(heureDebut));
                pl.setIdminuite(Integer.parseInt(minuteDebut));
                pl.setIdheurefin(Integer.parseInt(heureFin));
                pl.setIdminuitefin(Integer.parseInt(minuteFin));

                con.save(pl);
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=Plagehoraire.jsp");
                dp.forward(request, response);
            } catch (NamingException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=Plagehoraire.jsp");
                dp.forward(request, response);
            }
        } else if ("formSurveillant".equals(request.getParameter("formulaire"))) {
            String nomSurveillant = request.getParameter("nomSurveillant");
            String prenomSurveillant = request.getParameter("prenomSurveillant");
            String codeSurveillant = request.getParameter("codeSurveillant");
            String telephoneSurveillant = request.getParameter("telephoneSurveillant");

            try {
                Context context = new InitialContext();
                gestionaireFormLocal con = (gestionaireFormLocal) context.lookup("formBean");
                
                Surveillant sr=new Surveillant();
                sr.setCodesurveillant(codeSurveillant);
                sr.setNomsurveillant(nomSurveillant);
                sr.setPrenomsurveillant(prenomSurveillant);
                sr.setTelephone(telephoneSurveillant);
                
                con.save(sr);
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=Surveillant.jsp");
                dp.forward(request, response);
            } catch (NamingException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=Surveillant.jsp");
                dp.forward(request, response);
            }
        }else if ("formRessources".equals(request.getParameter("formulaire"))) {
            
            String coderessource = request.getParameter("coderessource");
            String libelle_fr = request.getParameter("libelle_fr");
            String libelle_en = request.getParameter("libelle_en");
            String description = request.getParameter("description");
            try {
                Context context = new InitialContext();
                gestionaireFormLocal con = (gestionaireFormLocal) context.lookup("formBean");

                Ressources res = new Ressources();
                res.setCoderessources(coderessource);
                res.setDescription(description);
                res.setLibelleEn(libelle_en);
                res.setLibelleFr(libelle_fr);
                
                con.save(res);
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=Ressources.jsp");
                dp.forward(request, response);
            } catch (NamingException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=Ressources.jsp");
                dp.forward(request, response);
            }
        }else if ("formProgrammeadopte".equals(request.getParameter("formulaire"))) {
            
            String anneeProgramme = request.getParameter("anneeProgramme");
            String option = request.getParameter("option");
            String semestre = request.getParameter("semestre");
            String programme = request.getParameter("programme");
            try {
                Context context = new InitialContext();
                gestionaireFormLocal con = (gestionaireFormLocal) context.lookup("formBean");

                Programmeadopte prd = new Programmeadopte();
                prd.setIdProgramme(Integer.parseInt(programme));
                prd.setIdannee(Integer.parseInt(anneeProgramme));
                prd.setIdoptions(Integer.parseInt(option));
                prd.setIdsemestre(Integer.parseInt(semestre));                  
                
                con.save(prd);
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=Programmeadopte.jsp");
                dp.forward(request, response);
            } catch (NamingException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=Programmeadopte.jsp");
                dp.forward(request, response);
            }
        }else if ("formPrg".equals(request.getParameter("formulaire"))) {
            
            int idsemestre = Integer.parseInt(request.getParameter("semestre1")); 
            int idmatierePrg = Integer.parseInt(request.getParameter("matierePrg"));
            int idsalle = Integer.parseInt(request.getParameter("salle"));
            int idplagehoraire = Integer.parseInt(request.getParameter("plagehoraire"));
            int idsession = Integer.parseInt(request.getParameter("session"));
            String dateplage = request.getParameter("dateplage");
            String codeprogrammation = request.getParameter("codeprogrammation");
            try {
                Context context = new InitialContext();
                gestionaireFormLocal con = (gestionaireFormLocal) context.lookup("formBean");

                Matiereprogrammee prd = new Matiereprogrammee();
                prd.setCodeprogrammtion(codeprogrammation);
                prd.setIdMatiere(idmatierePrg);
                prd.setIdSession(idsession);
                prd.setIdoptionsemestre(idsemestre);
                prd.setIdplagehoraire(idplagehoraire);
                prd.setIdsalle(idsalle);
                //---Traitement de la date------------- 
                Date dpl = null;
                try {
                    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
                    dpl = sdf2.parse(dateplage);
                } catch (RuntimeException e) {
                } catch (ParseException ex) {
                    Logger.getLogger(FormServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
                //---fin du traitement de la date-------
                prd.setDateprogrammee(dpl); 
                con.save(prd);
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=formProgramMatiereExam.jsp");
                dp.forward(request, response);
            } catch (NamingException e) {
                e.printStackTrace();
            } catch (NullPointerException e) {
                RequestDispatcher dp = request.getRequestDispatcher("Accueil.jsp?page=formProgramMatiereExam.jsp");
                dp.forward(request, response);
            }
        }

    }//------fin methode doPost-----

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>    
}
