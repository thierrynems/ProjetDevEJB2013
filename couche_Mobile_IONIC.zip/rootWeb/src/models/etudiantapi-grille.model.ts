import { UeApi } from './etudiantapi-ue.model';
export class GrilleApi {
    idprogramme: string;
    codeprogramme: string;
    libellePrg: string;
    nbrecredit: string;
    ue:UeApi[];
    matiere:UeApi[];
}