export class MessageApi {
    titre: string;
    description: string;
    date: string;
}