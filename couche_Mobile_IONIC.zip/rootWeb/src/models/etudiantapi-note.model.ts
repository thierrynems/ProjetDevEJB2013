export class NoteApi {
    code: string;
    libelle_fr: string;
    notecc: string;
    noteex: string;
    notefinale:string;
    codesession:string;
}