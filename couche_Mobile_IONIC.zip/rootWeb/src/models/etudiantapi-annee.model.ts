export class AnneeApi {
    code: string;
    libelle_fr: string;
}