export class EtudiantApi {
    matriculeetud: string;
    nometud: string;
    prenometud: string;
}