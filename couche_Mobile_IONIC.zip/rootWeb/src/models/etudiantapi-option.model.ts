export class OptionApi {
    codeoption: string;
    libelle_fr: string;
}