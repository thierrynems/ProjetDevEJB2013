import { NoteApi } from './etudiantapi-note.model';
export class EtudiantApiGlobal{
    matriculeetud: string;
    nometud: string;
    prenometud: string;
    noteEtud:NoteApi[];
}