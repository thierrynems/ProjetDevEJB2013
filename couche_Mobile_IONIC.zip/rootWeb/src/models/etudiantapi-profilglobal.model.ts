import { UeApi } from './etudiantapi-ue.model';
export class ProfilglobalApi {
    idsemestre: string;
    code: string;
    libelle_fr: string;
    ue:UeApi[];
    matiere:UeApi[];
}