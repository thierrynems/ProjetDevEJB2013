export class ClasseApi {
    code: string;
    libelle: string;
}