export class SessionApi {
    idSession: string;
    idannee:string;
    codesession:string;
    libelle_fr:string;
}