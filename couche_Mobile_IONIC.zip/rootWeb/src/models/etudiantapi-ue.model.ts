export class UeApi {
    codeue: string;
    libelleue: string;
    typeue: string;
    noteue: string;
    creditue: string;
    mentionue: string;
    session: string;
}