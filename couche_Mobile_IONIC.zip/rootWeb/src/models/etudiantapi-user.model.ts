export class UserApi {
    username: string;
    password: string;
    status:boolean;
    message: string;    
}