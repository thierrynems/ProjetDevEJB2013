import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { AccueilPage } from '../pages/accueil/accueil';
import { MessagePage } from '../pages/message/message';
import { ProfilPage } from '../pages/profil/profil';
import { RequetePage } from '../pages/requete/requete';
import { GrillePage } from '../pages/grille/grille';
import { NoteccPage } from '../pages/notecc/notecc';
import { AffichenotePage } from '../pages/notecc/affichenote';
import { AfficheprofilPage } from '../pages/profil/afficheprofil';
import { AffichegrillePage } from '../pages/grille/affichegrille';
import { ListPage } from '../pages/list/list';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { EtudiantApiService } from '../services/etudiantapi.service';
import { HttpModule } from '@angular/http';
import { EmploitempsPage } from '../pages/emploitemps/emploitemps';
import { AfficheemploitempsPage } from '../pages/emploitemps/afficheemploitemps';
import { MesrequetePage } from '../pages/requete/mesrequete';

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    ListPage,
    AccueilPage,
    MessagePage,
    ProfilPage,
    NoteccPage,
    AffichenotePage,
    AfficheprofilPage,
    RequetePage,
    GrillePage,
    AffichegrillePage,
    EmploitempsPage,
    AfficheemploitempsPage,
    MesrequetePage
  ],
  imports: [
    HttpModule,
    BrowserModule,
    IonicModule.forRoot(MyApp),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    ListPage,
    AccueilPage,
    MessagePage,
    ProfilPage,
    NoteccPage,
    AffichenotePage,
    AfficheprofilPage,
    RequetePage,
    GrillePage,
    AffichegrillePage,
    EmploitempsPage,
    AfficheemploitempsPage,
    MesrequetePage
  ],
  providers: [
    EtudiantApiService,
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
