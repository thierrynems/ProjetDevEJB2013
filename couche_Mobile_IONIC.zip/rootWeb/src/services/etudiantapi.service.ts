//core components
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

//RxJS
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';

import { EtudiantApiGlobal } from '../models/etudiantapi-global.model';
import { SessionApi } from '../models/etudiantapi-session.model';
import { MessageApi } from '../models/etudiantapi-message.model';
import { ClasseApi } from '../models/etudiantapi-classe.model';
import { ProfilglobalApi } from '../models/etudiantapi-profilglobal.model';
import { UserApi } from '../models/etudiantapi-user.model';
import { AnneeApi } from '../models/etudiantapi-annee.model';
import { OptionApi } from '../models/etudiantapi-option.model';
import { GrilleApi } from '../models/etudiantapi-grille.model';
import { UeApi } from '../models/etudiantapi-ue.model';

@Injectable()
export class EtudiantApiService{ 
    //private baseUrl: string='http://192.168.8.35/apirest/';
   // private baseUrl: string='http://192.168.43.237/apirest/';
    private baseUrl: string='http://192.168.43.2/apirest/';
  
    /* private source: string='cbs-news';
    private apikey: string ='3f660b446bee4b1882d4265d298e8c74';
    */
    matricule: string;
    constructor(private http: Http){

    }
    public getEtudiant() : Promise<EtudiantApiGlobal> {
      const url= `${this.baseUrl}etudiant?matricule=${this.matricule}`;
      console.log(url);
       //const url='https://newsapi.org/v1/articles?source=associated-press&apiKey=3f660b446bee4b1882d4265d298e8c74'; 
     //  const url= 'http://192.168.43.2/apirest/etudiant';
     // const url= `http://192.168.43.2/apirest/etudiant?matricule=13S0001`;
       return this.http.get(url)
        .toPromise()
        .then(response=>response.json() as EtudiantApiGlobal)
      //  .catch(error=>console.log('Une erreur est survenue '+error))
    }
    public getNotecc(matricule:string,idsession:string) : Promise<EtudiantApiGlobal> {
      this.matricule=matricule;
      const url= `${this.baseUrl}notecc?matricule=${this.matricule}&session=${idsession}`;
      console.log("ici session service= "+idsession);        
       return this.http.get(url)
        .toPromise()
        .then(response=>response.json() as EtudiantApiGlobal)
      //  .catch(error=>console.log('Une erreur est survenue '+error))
    }
    //service de note cc
    public getSession() : Promise<SessionApi> {
      const url= `${this.baseUrl}session`;
      console.log(url);
       return this.http.get(url)
        .toPromise()
        .then(response=>response.json() as SessionApi)
      //  .catch(error=>console.log('Une erreur est survenue '+error))
    }
    //service message 
    public getMessage() : Promise<MessageApi>{
      const url= `${this.baseUrl}message`;
      console.log(url);
       return this.http.get(url)
        .toPromise()
        .then(response=>response.json() as MessageApi)
      //  .catch(error=>console.log('Une erreur est survenue '+error))
    }

    //service Classe 
    public getClasse() : Promise<ClasseApi>{
      const url= `${this.baseUrl}classe`;
      console.log(url);
       return this.http.get(url)
        .toPromise()
        .then(response=>response.json() as ClasseApi)
      //  .catch(error=>console.log('Une erreur est survenue '+error))
    }

    //service Matiere 
    public getMatiere() : Promise<UeApi>{
      const url= `${this.baseUrl}matiere`;
      console.log(url);
       return this.http.get(url)
        .toPromise()
        .then(response=>response.json() as UeApi)
      //  .catch(error=>console.log('Une erreur est survenue '+error))
    }

     //service Classe 
     public getProfil(matriculeetud:string,classe:string) : Promise<ProfilglobalApi>{
      this.matricule=matriculeetud;
      const url= `${this.baseUrl}profil?matricule=${matriculeetud}&classe=${classe}`;
      console.log(url);
       return this.http.get(url)
        .toPromise()
        .then(response=>response.json() as ProfilglobalApi)
      //  .catch(error=>console.log('Une erreur est survenue '+error))
    }
    //service connexion
    public getUser(username:string,password:string) : Promise<UserApi>{
      const url= `${this.baseUrl}connexion?username=${username}&password=${password}`;
      console.log(url);
       return this.http.get(url)
        .toPromise()
        .then(response=>response.json() as UserApi)
      //  .catch(error=>console.log('Une erreur est survenue '+error))
    }

    //service Annee 
    public getAnnee() : Promise<AnneeApi>{
      const url= `${this.baseUrl}annees`;
      console.log(url);
       return this.http.get(url)
        .toPromise()
        .then(response=>response.json() as AnneeApi)
      //  .catch(error=>console.log('Une erreur est survenue '+error))
    }
//service Option 
public getOption() : Promise<OptionApi>{
  const url= `${this.baseUrl}options`;
  console.log(url);
   return this.http.get(url)
    .toPromise()
    .then(response=>response.json() as OptionApi)
  //  .catch(error=>console.log('Une erreur est survenue '+error))
}
//service Grille 
public getGrille(annee:string, option:string, classe:string) : Promise<GrilleApi>{
  const url= `${this.baseUrl}grilleprogramme?idannee=${annee}&idoptions=${option}&classe=${classe}`;
  console.log(url);
   return this.http.get(url)
    .toPromise()
    .then(response=>response.json() as GrilleApi)
  //  .catch(error=>console.log('Une erreur est survenue '+error))
}
//service Grille 
public getEmploiTemps(session:string, option:string, classe:string) : Promise<GrilleApi>{
  const url= `${this.baseUrl}emploistemps?idsession=${session}&idoptions=${option}&classe=${classe}`;
  console.log(url);
   return this.http.get(url)
    .toPromise()
    .then(response=>response.json() as GrilleApi)
  //  .catch(error=>console.log('Une erreur est survenue '+error))
}
//service mes requetes
public mesRequete(matricule:string) : Promise<MessageApi>{
  const url= `${this.baseUrl}mesrequete?matricule=${matricule}`;
  console.log(url);
   return this.http.get(url)
    .toPromise()
    .then(response=>response.json() as MessageApi)
  //  .catch(error=>console.log('Une erreur est survenue '+error))
}
//save requete
public saveRequete(matricule:string,idsession:string,idclasse:string,idmatiere:string,noteav:string,noteap:string,objet:string,message:string) : Promise<string>{
  const url= `${this.baseUrl}saveRequete?idsession=${idsession}&idclasse=${idclasse}&idmatiere=${idmatiere}&noteav=${noteav}&noteap=${noteap}&objet=${objet}&message=${message}&matricule=${matricule}`;
  console.log(url);
   return this.http.get(url)
    .toPromise()
    .then(response=>response.json() as string)
  //  .catch(error=>console.log('Une erreur est survenue '+error))
}

}