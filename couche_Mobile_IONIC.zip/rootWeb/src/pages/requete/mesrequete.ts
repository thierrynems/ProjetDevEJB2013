import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { MessageApi } from '../../models/etudiantapi-message.model';
import { EtudiantApiService } from '../../services/etudiantapi.service';

@Component({
  selector: 'page-mesrequete',
  templateUrl: 'mesrequete.html'
})
export class MesrequetePage {
 
  message: MessageApi = new MessageApi();
  matricule:string;
  constructor(public navCtrl: NavController, private etudiantApiService: EtudiantApiService,private navParams:NavParams) {
    this.matricule=navParams.get('matricule');
    this.etudiantApiService.mesRequete(this.matricule)
      .then(newsFetched =>{
        this.message=newsFetched;
        console.log(this.message);
      }); 
         
  }

}
