import { Component } from '@angular/core';
import { NavController, NavParams, AlertController, LoadingController } from 'ionic-angular';
import { SessionApi } from '../../models/etudiantapi-session.model';
import { EtudiantApiService } from '../../services/etudiantapi.service';
import { AccueilPage } from '../accueil/accueil';
import { ClasseApi } from '../../models/etudiantapi-classe.model';
import { UeApi } from '../../models/etudiantapi-ue.model';
import { NoteccPage } from '../notecc/notecc';

@Component({
  selector: 'page-requete',
  templateUrl: 'requete.html'
})
export class RequetePage {
 //etudiant: EtudiantApiGlobal = new EtudiantApiGlobal();
 session: SessionApi = new SessionApi();
 classe: ClasseApi= new ClasseApi();
 matiere: UeApi=new UeApi(); 
 idsession:string;
 idclasse:string;
 idmatiere:string;
 noteav:string;
 noteap:string;
 objet:string;
 message:string;
 matricule:string;
 result: string='Requete soumise avec succes! !!!';
 constructor(public navCtrl: NavController,private etudiantApiService:EtudiantApiService,private navParams:NavParams,public loadingCtrl: LoadingController,public alertCtrl: AlertController) {
     
   /*this.etudiantApiService.getEtudiant()
     .then(newsFetched =>{
       this.etudiant=newsFetched;
       console.log(this.etudiant);
     }); 
     */
     this.matricule=navParams.get('matricule');
     //get session
     this.etudiantApiService.getSession()
     .then(newsFetched =>{
       this.session=newsFetched;
       console.log(this.session);
     }); 
     //get classe
     this.etudiantApiService.getClasse()
     .then(newsFetched =>{
       this.classe=newsFetched;
       console.log(this.classe);
     }); 
      //get matiere
      this.etudiantApiService.getMatiere()
      .then(newsFetched =>{
        this.matiere=newsFetched;
        console.log(this.matiere);
      }); 
 }
 private SoumettreRequete(){
  this.etudiantApiService.saveRequete(this.matricule,this.idsession,this.idclasse,this.idmatiere,this.noteav,this.noteap,this.objet,this.message)
   .then(newsFetched =>{
    this.result=newsFetched;
    console.log(this.result);
      });

   ///waiting 
   const loader = this.loadingCtrl.create({
    content: "Please wait...",
    duration: 3000
  });
  loader.present();
  //alert
    const alert = this.alertCtrl.create({
      title: 'Reponse serveur!',
      subTitle: this.result,
      buttons: ['OK']
    });
    
    alert.present();  
  }


}
