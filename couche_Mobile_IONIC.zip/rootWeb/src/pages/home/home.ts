import { Component } from '@angular/core';
import { NavController,AlertController } from 'ionic-angular';

import { AccueilPage } from '../accueil/accueil';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
 
  username: string;
  password:string;
  
  constructor(public navCtrl: NavController) {
         
  }
  
  private connexionPage(){
    this.navCtrl.push(AccueilPage,{username:this.username,password:this.password});
   }

}
