import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { EtudiantApiService } from '../../services/etudiantapi.service';
import { ClasseApi } from '../../models/etudiantapi-classe.model';
import { AnneeApi } from '../../models/etudiantapi-annee.model';
import { OptionApi } from '../../models/etudiantapi-option.model';
import { AffichegrillePage } from './affichegrille';
@Component({
  selector: 'page-grille',
  templateUrl: 'grille.html'
})
export class GrillePage {
 
 
  matricule:string;
  annee: AnneeApi = new AnneeApi();
  option: OptionApi = new OptionApi();  
  classe: ClasseApi= new ClasseApi(); 
  idclasse:string;
  idannee:string;
  idoption:string;
  constructor(public navCtrl: NavController,private etudiantApiService:EtudiantApiService,private navParams: NavParams) {
    this.matricule=navParams.get('matricule');
    //service annee
    this.etudiantApiService.getAnnee()
    .then(newsFetched =>{
      this.annee=newsFetched;
      console.log(this.annee);
    }); 
    //service classe
    this.etudiantApiService.getClasse()
    .then(newsFetched =>{
      this.classe=newsFetched;
      console.log(this.classe);
    }); 
    //service Option
    this.etudiantApiService.getOption()
    .then(newsFetched =>{
      this.option=newsFetched;
      console.log(this.option);
    });
  }
  private AfficheGrille(){
    console.log("option="+this.idoption+" annee="+this.idannee);
    this.navCtrl.push(AffichegrillePage,{matricule:this.matricule, idclasse:this.idclasse,idannee:this.idannee,idoption:this.idoption});
   }

}
