import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { EtudiantApiService } from '../../services/etudiantapi.service';
import { ClasseApi } from '../../models/etudiantapi-classe.model';
import { GrilleApi } from '../../models/etudiantapi-grille.model';
@Component({
  selector: 'page-affichegrille',
  templateUrl: 'affichegrille.html'
})
export class AffichegrillePage {
 
  classe: ClasseApi= new ClasseApi(); 
  grille: GrilleApi= new GrilleApi(); 
  idclasse:string;
  idannee:string;
  idoption:string;
  matricule:string;
  constructor(public navCtrl: NavController,private etudiantApiService:EtudiantApiService,private navParams: NavParams) {
   /* this.etudiantApiService.getClasse()
    .then(newsFetched =>{
      this.classe=newsFetched;
      console.log(this.classe);
    }); 
    */
     this.idclasse=navParams.get('idclasse');
     this.idannee=navParams.get('idannee');
     this.idoption=navParams.get('idoption');
     this.matricule=navParams.get('matricule');

     this.etudiantApiService.getGrille(this.idannee, this.idoption, this.idclasse)
    .then(newsFetched =>{
      this.grille=newsFetched;
      console.log(this.grille);
    }); 
     /*
    this.etudiantApiService.getProfil(this.matricule,this.idclasse)
    .then(newsFetched =>{
      this.profil=newsFetched;
      console.log(this.profil);
    }); 
    */
  }

}