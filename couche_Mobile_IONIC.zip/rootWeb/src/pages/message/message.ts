import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

import { MessageApi } from '../../models/etudiantapi-message.model';
import { EtudiantApiService } from '../../services/etudiantapi.service';

@Component({
  selector: 'page-message',
  templateUrl: 'message.html'
})
export class MessagePage {
 
  message: MessageApi = new MessageApi();
  constructor(public navCtrl: NavController, private etudiantApiService: EtudiantApiService) {
    this.etudiantApiService.getMessage()
      .then(newsFetched =>{
        this.message=newsFetched;
        console.log(this.message);
      }); 
         
  }

}
