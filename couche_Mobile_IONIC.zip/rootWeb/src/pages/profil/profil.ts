import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { EtudiantApiGlobal } from '../../models/etudiantapi-global.model';
import { EtudiantApiService } from '../../services/etudiantapi.service';
import { ClasseApi } from '../../models/etudiantapi-classe.model';
import { AfficheprofilPage } from '../profil/afficheprofil';
@Component({
  selector: 'page-profil',
  templateUrl: 'profil.html'
})
export class ProfilPage {
 
  classe: ClasseApi= new ClasseApi(); 
  etudiant: EtudiantApiGlobal = new EtudiantApiGlobal();
  idclasse:string;
  matricule:string;
  constructor(public navCtrl: NavController,private etudiantApiService:EtudiantApiService,private navParams: NavParams) {
    this.matricule=navParams.get('matricule');
    this.etudiantApiService.getEtudiant()
    .then(newsFetched =>{
      this.etudiant=newsFetched;
      console.log(this.etudiant);
    }); 
    
    this.etudiantApiService.getClasse()
    .then(newsFetched =>{
      this.classe=newsFetched;
      console.log(this.classe);
    }); 
  }
  private AfficheProfil(){
    this.navCtrl.push(AfficheprofilPage,{matricule:this.matricule, idclasse:this.idclasse});
   }

}
