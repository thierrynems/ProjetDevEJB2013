import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { App, MenuController } from 'ionic-angular';

import { EtudiantApiGlobal } from '../../models/etudiantapi-global.model';
import { UserApi } from '../../models/etudiantapi-user.model';
import { EtudiantApiService } from '../../services/etudiantapi.service';
import { MessagePage } from '../message/message';
import { NoteccPage } from '../notecc/notecc';
import { ProfilPage } from '../profil/profil';
import { HomePage } from '../home/home';
import { RequetePage } from '../requete/requete';
import { GrillePage } from '../grille/grille';
import { EmploitempsPage } from '../emploitemps/emploitemps';
import { MesrequetePage } from '../requete/mesrequete';

@Component({
  selector: 'page-accueil',
  templateUrl: 'accueil.html'
})
export class AccueilPage {
    
    username: string;
    password:string;
    etudiant: EtudiantApiGlobal = new EtudiantApiGlobal();
    user:UserApi = new UserApi();
    constructor(app: App, menu: MenuController,public navCtrl: NavController,private etudiantApiService:EtudiantApiService,private navParams: NavParams) {
      menu.enable(true);  
      this.etudiantApiService.getEtudiant()
      .then(newsFetched =>{
        this.etudiant=newsFetched;
        console.log(this.etudiant);
      }); 
    this.username=navParams.get('username');
    this.password=navParams.get('password'); 
      ///service de connexion 
      this.etudiantApiService.getUser(this.username,this.password)
      .then(newsFetched =>{
        this.user=newsFetched;
        console.log(this.user);
      }); 
    }

    private ouvrirMessage() {
      // That's right, we're pushing to ourselves!
      this.navCtrl.push(MessagePage);
     console.log("ici"); 
    }

    //ouvrir note CC
    private ouvrirNote() {
      // That's right, we're pushing to ourselves!
      this.navCtrl.push(NoteccPage,{matricule:this.username});
     console.log("ici"); 
    }
    
    //ouvrir Profil
    private ouvrirProfil() {
      // That's right, we're pushing to ourselves!
      this.navCtrl.push(ProfilPage,{matricule:this.username});
     console.log("ici"); 
    }
     //ouvrir Reuete
     private ouvrirRequete() {
      // That's right, we're pushing to ourselves!
      this.navCtrl.push(RequetePage,{matricule:this.username});
      console.log("ici"); 
    }
     //ouvrir Reuete
     private ouvrirGrille() {
      // That's right, we're pushing to ourselves!
      this.navCtrl.push(GrillePage,{matricule:this.username});
      console.log("ici"); 
    }
    //Ouvrir emploi de temps
    private ouvrirEmploiTemps(){
      this.navCtrl.push(EmploitempsPage,{matricule:this.username}); 
    }
    //Ouvrir emploi de temps
    private ouvrirMesrequete(){
      this.navCtrl.push(MesrequetePage,{matricule:this.username}); 
    }
  //ouvrir Profil
  private Deconnexion() {
    // That's right, we're pushing to ourselves!
    this.navCtrl.push(HomePage);
   console.log("ici"); 
  }

}
