import { Component } from '@angular/core';
import { NavController,NavParams } from 'ionic-angular';
//import { NoteApi } from '../../models/etudiantapi-note.model';
import { EtudiantApiGlobal } from '../../models/etudiantapi-global.model';
//import { SessionApi } from '../../models/etudiantapi-session.model';
import { EtudiantApiService } from '../../services/etudiantapi.service';

@Component({
  selector: 'page-affichenote',
  templateUrl: 'affichenote.html'
})
export class AffichenotePage {
  idsession:string;
  matricule:string;
  etudiant: EtudiantApiGlobal = new EtudiantApiGlobal();
 // session: SessionApi = new SessionApi();
  constructor(public navCtrl: NavController,private etudiantApiService:EtudiantApiService,public navParams: NavParams) {
    this.idsession = navParams.get('idsession');
    this.matricule=navParams.get('matricule');
    this.etudiantApiService.getNotecc(this.matricule,this.idsession)
      .then(newsFetched =>{
        this.etudiant=newsFetched;
        console.log(this.etudiant);
      }); 
       
  }


}
