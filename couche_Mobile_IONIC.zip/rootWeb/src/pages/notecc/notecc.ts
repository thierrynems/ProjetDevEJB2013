import { Component } from '@angular/core';
import { NavController, NavParams} from 'ionic-angular';
//import { NoteApi } from '../../models/etudiantapi-note.model';
//import { EtudiantApiGlobal } from '../../models/etudiantapi-global.model';
import { SessionApi } from '../../models/etudiantapi-session.model';
import { EtudiantApiService } from '../../services/etudiantapi.service';
import { AffichenotePage } from '../notecc/affichenote';
@Component({
  selector: 'page-notecc',
  templateUrl: 'notecc.html'
})
export class NoteccPage {
 
  //etudiant: EtudiantApiGlobal = new EtudiantApiGlobal();
  session: SessionApi = new SessionApi();
  idsession:string;
  selectOptions:any;
  matricule:string;
  constructor(public navCtrl: NavController,private etudiantApiService:EtudiantApiService,private navParams:NavParams) {
      
    /*this.etudiantApiService.getEtudiant()
      .then(newsFetched =>{
        this.etudiant=newsFetched;
        console.log(this.etudiant);
      }); 
      */
     this.matricule=navParams.get('matricule');
      this.etudiantApiService.getSession()
      .then(newsFetched =>{
        this.session=newsFetched;
        console.log(this.session);
      }); 
  }
  private AfficheNote(){
    this.navCtrl.push(AffichenotePage,{idsession:this.idsession,matricule:this.matricule});
   }

}
