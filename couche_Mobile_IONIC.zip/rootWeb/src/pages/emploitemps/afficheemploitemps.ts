import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { EtudiantApiService } from '../../services/etudiantapi.service';
import { ClasseApi } from '../../models/etudiantapi-classe.model';
import { GrilleApi } from '../../models/etudiantapi-grille.model';
@Component({
  selector: 'page-afficheemploitemps',
  templateUrl: 'afficheemploitemps.html'
})
export class AfficheemploitempsPage {
 
  classe: ClasseApi= new ClasseApi(); 
  grille: GrilleApi= new GrilleApi(); 
  idclasse:string;
  idsession:string;
  idoption:string;
  matricule:string;
  constructor(public navCtrl: NavController,private etudiantApiService:EtudiantApiService,private navParams: NavParams) {
  
     this.idclasse=navParams.get('idclasse');
     this.idsession=navParams.get('idsession');
     this.idoption=navParams.get('idoption');
     this.matricule=navParams.get('matricule');

     this.etudiantApiService.getEmploiTemps(this.idsession, this.idoption, this.idclasse)
    .then(newsFetched =>{
      this.grille=newsFetched;
      console.log(this.grille);
    }); 
     
  }

}