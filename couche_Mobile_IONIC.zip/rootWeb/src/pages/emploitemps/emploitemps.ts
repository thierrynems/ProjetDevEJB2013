import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';

import { EtudiantApiService } from '../../services/etudiantapi.service';
import { ClasseApi } from '../../models/etudiantapi-classe.model';
import { AfficheprofilPage } from '../profil/afficheprofil';
import { OptionApi } from '../../models/etudiantapi-option.model';
import { SessionApi } from '../../models/etudiantapi-session.model';
import { AfficheemploitempsPage } from './afficheemploitemps';
@Component({
  selector: 'page-emploitemps',
  templateUrl: 'emploitemps.html'
})
export class EmploitempsPage {
 
  classe: ClasseApi= new ClasseApi(); 
  option: OptionApi = new OptionApi(); 
  session: SessionApi = new SessionApi();
  idclasse:string;
  idoption:string;
  idsession:string;
  matricule:string;
  constructor(public navCtrl: NavController,private etudiantApiService:EtudiantApiService,private navParams: NavParams) {
    this.matricule=navParams.get('matricule');   
    this.etudiantApiService.getClasse()
    .then(newsFetched =>{
      this.classe=newsFetched;
      console.log(this.classe);
    }); 
    //service session
    this.etudiantApiService.getSession()
    .then(newsFetched =>{
      this.session=newsFetched;
      console.log(this.session);
    }); 
     //service options
     this.etudiantApiService.getOption()
     .then(newsFetched =>{
       this.option=newsFetched;
       console.log(this.option);
     }); 
  }

  private AfficheEmploi(){
    this.navCtrl.push(AfficheemploitempsPage,{matricule:this.matricule, idclasse:this.idclasse,idoption:this.idoption,idsession:this.idsession});
   }

}
